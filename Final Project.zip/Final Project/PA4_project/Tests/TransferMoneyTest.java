/**
 * Tests for transfer money transaction
 * @author Laura Blanco
 * @author Lidice Castro
 * @version 3, November 8,2020
 */

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Hashtable;

import static org.junit.jupiter.api.Assertions.*;

class TransferMoneyTest {

    String fileName = "CS 3331 - Bank Users 4.csv";
    BankHT bht = new BankHT(fileName);
    Hashtable<String,Customer> bankUsersByName = bht.getUsersByNameHT();

    @Test
    @DisplayName("Test transfer money transaction from Savings account to another account.")
    void transferMoney() {

        //Variables and objects
        Customer Acc = bankUsersByName.get("mickeymouse");

        //Create savings object
        Savings userSavings = Acc.getSaving();
        Checking userChecking = Acc.getCheck();

        //Get initial values
        double amount = 100;
        double userInitialBalance = userSavings.getBalance();
        double userInitialBalance2 = userChecking.getBalance();

        //Do transactions
        boolean test = userSavings.transferMoney(amount,userChecking, Acc);

        assertTrue(test);
        assertEquals(userInitialBalance-amount, userSavings.getBalance());
        assertEquals(userInitialBalance2+amount, userChecking.getBalance());
    }

    @Test
    @DisplayName("Test transfer money transaction from Savings account to another account with insufficient balance.")
    void transferMoneyInsufficient() {
        //Variables and objects
        Customer Acc = bankUsersByName.get("mickeymouse");

        //Create savings object
        Savings userSavings = Acc.getSaving();
        Checking userChecking = Acc.getCheck();

        //Get initial values
        double amount = 5000;

        //Do transactions
        boolean test = userSavings.transferMoney(amount,userChecking, Acc);

        assertFalse(test);
    }

    @Test
    @DisplayName("Test transfer money transaction from Savings account to another account with invalid amount.")
    void transferMoneyInvalid() {
        //Variables and objects
        Customer Acc = bankUsersByName.get("mickeymouse");

        //Create savings object
        Savings userSavings = Acc.getSaving();
        Checking userChecking = Acc.getCheck();

        //Get initial values
        double amount = -900;

        //Do transactions
        boolean test = userSavings.transferMoney(amount,userChecking, Acc);

        assertFalse(test);
    }
}