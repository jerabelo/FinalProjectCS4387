/**
 * Tests for make deposit transaction
 * @author Laura Blanco
 * @author Lidice Castro
 * @version 3, November 8,2020
 */

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.util.Hashtable;

import static org.junit.jupiter.api.Assertions.*;

class MakeDepositTest {

    String fileName = "CS 3331 - Bank Users 4.csv";
    BankHT bht = new BankHT(fileName);
    Hashtable<String,Customer> bankUsersByName = bht.getUsersByNameHT();

    @Test
    @DisplayName("Test make deposit transaction using Savings account and a valid amount.")
    void makeDeposit() {
        //Variables and objects
        Customer savedAcc = bankUsersByName.get("mickeymouse");

        //Create savings object
        Savings userSavings = savedAcc.getSaving();

        //Amounts
        double amount = 100;
        double initialBalance = userSavings.getBalance();

        //Verify if transaction is valid
        boolean test = userSavings.verifyDeposit(amount, savedAcc);

        //Do transaction
        userSavings.deposit(amount);

        assertTrue(test);
        assertEquals(initialBalance+amount, userSavings.getBalance());
    }

    @Test
    @DisplayName("Test make deposit transaction using Savings account and an invalid amount.")
    void makeDeposit2() {
        //Variables and objects
        Customer savedAcc = bankUsersByName.get("mickeymouse");

        //Create savings object
        Savings userSavings = savedAcc.getSaving();

        //Deposits can't accept negative numbers
        double amount = -100;
        boolean test = userSavings.verifyDeposit(amount, savedAcc);

        assertFalse(test);
    }
}