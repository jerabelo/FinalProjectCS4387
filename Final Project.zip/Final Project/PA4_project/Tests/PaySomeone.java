/**
 * Tests for pay someone transaction
 * @author Laura Blanco
 * @author Lidice Castro
 * @version 3, November 8,2020
 */

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Hashtable;

import static org.junit.jupiter.api.Assertions.*;

class PaySomeone {

    String fileName = "CS 3331 - Bank Users 4.csv";
    BankHT bht = new BankHT(fileName);
    Hashtable<String,Customer> bankUsersByName = bht.getUsersByNameHT();

    @Test
    @DisplayName("Test pay money transaction from Savings account to user account.")
    void transferMoney() {
        //Create savings object
        Customer Acc1 = bankUsersByName.get("mickeymouse");
        Savings userSavings = Acc1.getSaving();
        Customer Acc2 = bankUsersByName.get("donaldduck");
        Checking userChecking = Acc2.getCheck();
        //Get initial values
        double amount = 53;
        double userInitialBalance = userSavings.getBalance();
        double recipientInitialBalance = userChecking.getBalance();

        //Execute transactions
        boolean test = userSavings.paySomeone(amount,Acc2,Acc1);

        assertTrue(test);
        assertEquals(userInitialBalance-amount, userSavings.getBalance());
        assertEquals(recipientInitialBalance+amount, userChecking.getBalance());
    }

    @Test
    @DisplayName("Test pay money transaction from Savings account to another user with insufficient balance.")
    void transferMoneyInsufficient() {
        //Create savings object
        Customer Acc1 = bankUsersByName.get("belledisney");
        Savings userSavings1 = Acc1.getSaving();
        Customer Acc2 = bankUsersByName.get("auroradisney");

        //Get initial values
        double amount = 10000;

        //Execute transactions
        boolean test = userSavings1.paySomeone(amount,Acc2,Acc1);

        assertFalse(test);
    }

    @Test
    @DisplayName("Test pay money transaction from Savings account to another user with invalid amount.")
    void transferMoneyInvalid() {
        //Create savings object
        Customer Acc1 = bankUsersByName.get("belledisney");
        Savings userSavings1 = Acc1.getSaving();
        Customer Acc2 = bankUsersByName.get("auroradisney");

        //Get initial values
        double amount = -1;

        //Execute transactions
        boolean test = userSavings1.paySomeone(amount,Acc2,Acc1);

        assertFalse(test);
    }

    @Test
    @DisplayName("Test pay money transaction from Savings account to itself.")
    void transferMoneySameUser() {
        //Create savings object
        Customer Acc1 = bankUsersByName.get("belledisney");
        Savings userSavings1 = Acc1.getSaving();
        Customer Acc2 = bankUsersByName.get("belledisney");

        //Get initial values
        double amount = -1;

        //Execute transactions
        boolean test = userSavings1.paySomeone(amount,Acc2,Acc1);

        assertFalse(test);
    }
}