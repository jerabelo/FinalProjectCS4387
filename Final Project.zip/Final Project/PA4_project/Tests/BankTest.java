import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

class BankTest {

    /***
     //assertTrue
     //assertFalse  */

    @org.junit.jupiter.api.Test
    void transfer() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        int money = -500;
        String accType = "Checking";
        String toAcc = "Saving";
        Customer test1 = new Customer();
        test1.transfer(money,accType, toAcc,false);

        String expected = "Invalid number you can not transfer negative values\n";
        assertEquals(expected, outContent.toString());
    }

    @org.junit.jupiter.api.Test
    void transfer2() {
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        int money = 100;
        String accType = "Checking";
        String toAcc = "Savings";
        String first = "Laura";
        String last = "Blanco";
        String dob = "November 22 1990";
        int identity = 1;
        String address = "5000 Schuster";
        String phone = "9159000";
        Checking check = new Checking(4,200.0,true);
        Savings save = new Savings(5,800.0,true);
        Credit credit = new Credit(6,-250.0,5000,true);
        Customer test1 = new Customer(first,last,dob,identity,address,phone,"hi","laura@mail.com",check,save,credit);
        test1.transfer(money,accType, toAcc,false);

        String expected = "Successfully transferred: 100.0\nNew account balance in Checking: 100.0\nNew account balance in Savings: 900.0\n";
        assertEquals(expected, outContent.toString());
    }

}