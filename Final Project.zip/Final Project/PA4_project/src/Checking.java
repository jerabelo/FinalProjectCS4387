/**
 * Class that holds the checking account balance and number and inherits from account class
 * @author Laura Blanco
 * @version 4, November 7,2020
 */

public class Checking extends Account{
    //CONSTRUCTOR
    public Checking (){
        super();
    }  //calls parent class

    /**
     * This constructor will set the account number and balance
     * @param accountNumberIn Parameter is the account number of checking account
     * @param balanceIn Parameter is the balance of checking account
     * @param hasAccount Parameter that determines whether the user has this type of account
     */
    //Constructor to set the attributes to the object
    public Checking(int accountNumberIn,double balanceIn, boolean hasAccount){
        super(accountNumberIn,balanceIn,hasAccount, "Checking"); //calls parent class constructor

    }
}

