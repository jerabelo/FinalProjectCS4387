/**
 * Class that holds the customer attributes and holds methods that have certain actions a customer can do.
 * @author Laura Blanco
 * @author Lidice Castro
 * @version 4, November 7,2020
 */

//hi

import java.text.SimpleDateFormat;
import java.util.*;

public class Customer extends Person{
    //ATTRIBUTES
    private String address;
    private String DOB;
    private String phoneNum;
    private int identificationNum;
    private String password;
    private String email;
    private Checking check;
    private Savings saving;
    private Credit credit;
    private double savBegBal;
    private double checkBegBal;
    private double credBegBal;
    private BankStatement bS = new BankStatement();
    private ArrayList<String[]> transactions = new ArrayList<>();
    private SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
    private Date date = new Date();

    //CONSTRUCTORS
    /**
     *Default constructor
     */
    public Customer(){ }

    /**
     * Constructor will set attributes of customer object
     * @param firstName name of customer
     * @param lastName last name of customer
     * @param dobIn customer date of birth
     * @param identificationNumIn identifier number of customer
     * @param addressIn address of customer
     * @param phoneIn phone number of customer
     * @param checkingIn Parameter of type account that holds checking account number and balance
     * @param savingsIn Parameter of type account that holds savings account number and balance
     * @param creditIn Parameter of type account that holds credit account number and balance
     */
    public Customer(String firstName, String lastName,String dobIn, int identificationNumIn, String addressIn,
                    String phoneIn, String passwordIn, String emailIn, Checking checkingIn , Savings savingsIn, Credit creditIn){
        super(firstName,lastName);
        this.address = addressIn;
        this.DOB = dobIn;
        this.phoneNum = phoneIn;
        this. identificationNum = identificationNumIn;
        this.password = passwordIn;
        this.email = emailIn;
        this.check = checkingIn;
        this.saving = savingsIn;
        this.credit = creditIn;
    }

    //SETTERS AND GETTERS
    public ArrayList<String[]> getTransactions(){
        return this.transactions;
    }
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public int getIdentificationNum() {
        return identificationNum;
    }

    public void setIdentificationNum(int identificationNum) {
        this.identificationNum = identificationNum;
    }

    public Checking getCheck() {
        return check;
    }

    public void setCheck(Checking check) {
        this.check = check;
    }

    public Savings getSaving() {
        return saving;
    }

    public void setSaving(Savings saving) {
        this.saving = saving;
    }

    public Credit getCredit() {
        return credit;
    }

    public void setCredit(Credit credit) {
        this.credit = credit;
    }

    public double getSavBegBal() {
        return savBegBal;
    }

    public void setSavBegBal(double savBegBal) {
        this.savBegBal = savBegBal;
    }

    public double getCheckBegBal() {
        return checkBegBal;
    }

    public void setCheckBegBal(double checkBegBal) {
        this.checkBegBal = checkBegBal;
    }

    public double getCredBegBal() {
        return credBegBal;
    }

    public void setCredBegBal(double credBegBal) {
        this.credBegBal = credBegBal;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    //METHODS

    //Auxiliary Methods

    /**
     * @author Lidice Castro
     * This methods gets the account name of the object
     * @param userAccIn Parameter of type account that holds the account of the user
     * @return String that will hold the account type the user is using
     */
    public String getAccName(Account userAccIn){
        String accType;
        //Check if account is checking
        if(userAccIn == check){
            accType = "checking";
        }
        //Check if account is credit
        else if(userAccIn == credit){
            accType = "credit";
        } else{ //Check if account is saving
            accType = "saving";
        }
        return accType;
    }

    //Catch Exception Methods

    /**
     * @author Laura Blanco
     * This methods catches exception of type Double
     * @param in Parameter of type Scanner
     * @return Returns a double variable.
     */
    public static double catchExceptionsDouble(Scanner in){  //catches inputs other than double and int
        double value;
        while(true) {
            try {
                value = in.nextDouble();  //will prompt the user to enter a value
                break;
            } catch (InputMismatchException e) {   //catches if the value is not a double
                System.out.println("Invalid input. Numbers only please. ");
                in.nextLine();  //will prompt the user to enter again until value is valid
            }
        }
        return value;
    }

    //Transactions methods

    /**@author Lidice Castro
     * This methods determines what transaction the user wants to perform and will call other methods to do them
     * @param accountType Parameter of type String that contains the account type to make the transaction
     * @param transactionNum Parameter of type integer that contains the number of transaction selected by the user.
     * @param bankUsersByName Parameter of type Hashtable that contains the accounts of the bank users.
     */
    public void executeUserTransaction(int transactionNum, String accountType, Hashtable<String, Customer> bankUsersByName ){
        UserInterface ui = new UserInterface(bankUsersByName);
        //"Check balance", "Make a deposit", "Transfer money", "Pay someone", "Withdraw money"
        String dstAccName, srcAccName;

        //Execute transaction
        if(accountType.equals("Checking")){
            //Check balance
            if(transactionNum == 1) {
                this.checkBalance(this.getCheck());
            }
            //Make deposit
            else if (transactionNum == 2){
                this.makeDeposit(this.getCheck());
            }
            //Transfer money
            else if(transactionNum == 3 && (this.getCheck().isHasAccount() || this.getCredit().isHasAccount())){
                srcAccName = accountType;
                dstAccName = ui.selectToWhichAccount(srcAccName, this.getCheck().isHasAccount(), this.getSaving().isHasAccount(), this.getCredit().isHasAccount());
                if(dstAccName.equals("Savings")){
                    this.transferMoney(this.getCheck(), this.getSaving());
                }
                else{
                    this.transferMoney(this.getCheck(), this.getCredit());
                }
            }
            else if(transactionNum == 3 && !(this.getCheck().isHasAccount()) && !(this.getCredit().isHasAccount())){
                String denial = "Exception: Can't continue with transaction you don't have a Checking or Credit account to transfer";
                //logs it
                BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
                System.out.println(denial);

            }
            //Pay someone
            else if(transactionNum == 4){
                this.paySomeone(this.getCheck(), bankUsersByName);
            }
            else{
                //Withdraw money
                this.withdrawMoney(this.getCheck());
            }
        }
        else if(accountType.equals("Savings")){
            //Check balance
            if(transactionNum == 1){
                this.checkBalance(this.getSaving());
            }
            //Make deposit
            else if (transactionNum == 2){
                this.makeDeposit(this.getSaving());
            }
            //Transfer money
            else if(transactionNum == 3 && (this.getCheck().isHasAccount() || this.getCredit().isHasAccount())){
                srcAccName = accountType;
                dstAccName = ui.selectToWhichAccount(srcAccName, this.getCheck().isHasAccount(), this.getSaving().isHasAccount(), this.getCredit().isHasAccount());
                if(dstAccName.equals("Checking")){
                    this.transferMoney(this.getSaving(), this.getCheck());
                }
                else{
                    this.transferMoney(this.getSaving(), this.getCredit());
                }
            }
            else if(transactionNum == 3 && !(this.getCheck().isHasAccount()) && !(this.getCredit().isHasAccount())){
                String denial = "Exception: Can't continue with transaction you don't have a Checking or Credit account to transfer";
                //logs it
                BankLog.failedTransaction(0,"transfer","saving",this,denial,this);
                System.out.println(denial);
            }
            //Pay someone
            else if(transactionNum == 4){
                this.paySomeone(this.getSaving(), bankUsersByName);
            }
            //Withdraw money
            else{
                this.withdrawMoney(this.getSaving());
            }
        }
        //Account type is credit
        else{
            if(transactionNum == 1){
                this.checkBalance(this.getCredit());
            }
            else if (transactionNum == 2){
                this.makeDeposit(this.getCredit());
            }

        }

    }

    /**
     * @author Lidice Castro
     * This methods shows the user their balance
     * @param userAccIn Parameter of type Account that contains the information of the user.
     */
    public void checkBalance(Account userAccIn){
        String accType = getAccName(userAccIn);
        //Console view
        System.out.println("----------------------------------------------------------------\n");
        System.out.print("Available balance:");
        System.out.printf("\t\t%.2f\n",userAccIn.getBalance());
        //Save in log
        BankLog.successfulTransactions(0,"inquiry",accType,accType,this,this);
    }

    /**
     * @author Lidice Castro
     * This method performs the deposit to the specific account
     * @param userAccIn Parameter of type Account that contains the information of the user.
     */
    public void makeDeposit(Account userAccIn){
        //Variables and objects
        double amount;
        boolean verifytransaction;

        String accountName = this.getAccName(userAccIn);
        double balance = 0;
        Scanner sc = new Scanner(System.in);

        System.out.println("----------------------------------------------------------------\n");
        //Ask the user the amount to deposit
        System.out.println("Enter amount to deposit");
        amount = catchExceptionsDouble(sc);
        verifytransaction = userAccIn.verifyDeposit(amount, this);
        //Make a deposit to user account
        if(verifytransaction){
            //deposit the money into corresponding account
            if(userAccIn instanceof Checking){
                balance = this.getCheck().deposit(amount);
            }
            if(userAccIn instanceof Savings){
                balance = this.getSaving().deposit(amount);
            }
            if(userAccIn instanceof Credit){
                balance = this.getCredit().deposit(amount);
            }
            //print successful transaction
            System.out.println("\nYour transaction was successful! " + this.getFirstName() + " " + this.getLastName() + " deposited $" + amount + " to " + accountName + ".");
            //log the transaction
            BankLog.successfulTransactions(amount, "deposited", accountName,accountName,this,this );
            //Add transaction to array for bank statement
            addToTransactions("deposit",userAccIn,amount);
            System.out.println("Current " + accountName + " balance: " + balance);
        }

    }

    /**
     * @author Lidice Castro
     * This method withdraws from the specific account
     * @param userAccIn Parameter of type Account that contains the information of the user.
     */
    public void withdrawMoney(Account userAccIn){
        //Variables and objects
        double amount;
        boolean verifyTransaction;

        //Get user info
        String userAccName = getAccName(userAccIn);
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter amount you want to withdraw: ");
        amount = catchExceptionsDouble(sc); //catches exceptions
        //Do transaction
        verifyTransaction = userAccIn.withdrawMoney(amount, this);
        if(verifyTransaction){
            //Print successful transaction message
            System.out.println("\nSuccessful transaction. " + this.getFirstName() + " " + this.getLastName() + " withdrew $" + amount + " from " + userAccName + " account.");
           //logs it
            BankLog.successfulTransactions(amount,"withdrew", userAccName,userAccName, this,this);
            //Add transaction to array for bank statement
            addToTransactions("withdrawal",userAccIn,amount);

        }
        //Print current balance
        System.out.println("Current " + userAccName + " balance: " + userAccIn.getBalance());

    }

    /**
     * @author Lidice Castro
     * This method transfers money from one account to another
     * @param srcAccIn Parameter of type Account that contains the information of the user.
     * @param dstAccIn Parameter of type Account that contains the information of the recipient.
     */
    public void transferMoney(Account srcAccIn, Account dstAccIn){
        //variables and objects
        double amount;
        boolean verifytransaction;

        //Get user info
        String srcAccName = getAccName(srcAccIn);
        String dstAccName = getAccName(dstAccIn);
        Scanner sc = new Scanner(System.in);


        System.out.println("Transfer money from " + srcAccName + " to " + dstAccName);
        //Ask the user the amount to deposit
        System.out.println("Enter amount you want to transfer");
        amount = catchExceptionsDouble(sc);

        //Verify if transaction is valid
        verifytransaction = srcAccIn.transferMoney(amount,dstAccIn, this);

        //If true, do transaction
        if(verifytransaction){
            System.out.println("Successful transaction. " + this.getFirstName() + " " + this.getLastName() + " transferred $" + amount + " from " + srcAccName + " to " + dstAccName + ".");
            //logs transaction
            BankLog.successfulTransactions(amount,"transferred",srcAccName,dstAccName,this,this);
            //Add transaction to array for bank statement
            addToTransactions("transfer",srcAccIn,dstAccIn,amount);

        }
        System.out.println("Current " + srcAccName + " balance: " + srcAccIn.getBalance());

    }

    /**
     * @author Laura Blanco
     * @author Lidice Castro
     * This method pays another user
     * @param srcAccIn Parameter of type Account that contains the information of the user.
     * @param accounts Parameter of type Hashtable that contains the accounts of the bank users.
     */
    public void paySomeone(Account srcAccIn, Hashtable<String,Customer> accounts){
        //variables and objects
        double amount;
        boolean verifyTransaction = false;
        //Get user info
        String srcAccName = getAccName(srcAccIn);

        Scanner sc = new Scanner(System.in);

        System.out.println("----------------------------------------------------------------\n");

        //infinite for loop
        for(;;){

            System.out.println();
            System.out.println("Enter first name of person you want to pay: ");
            String recipientFirst = UserInterface.catchExceptionsString(sc); //calls method to make sure input is correct
            System.out.println("Enter last name");
            String recipientLast = UserInterface.catchExceptionsString(sc);
            String userKey = recipientFirst + recipientLast;

            if(accounts.containsKey(userKey.toLowerCase())){ //make sure the user exists
                Customer recipient = accounts.get(userKey.toLowerCase());
                if(recipient.getCheck().isHasAccount()){  //if user has checking
                    System.out.println("Enter amount you want to pay: ");
                    amount = catchExceptionsDouble(sc);
                    verifyTransaction = srcAccIn.paySomeone(amount,recipient,this); //calls method to perform transaction
                    if(verifyTransaction){
                        //print successful transaction
                        System.out.println("Your transaction was successful! " + this.getFirstName() + " " + this.getLastName() + " deposited $" + amount + " to " + recipient.getFirstName() + " " + recipient.getLastName() + ".");
                        //logs the transaction
                        BankLog.successfulTransactions(amount, "payed",srcAccName,srcAccName,recipient ,this);
                        //Add transaction to array for bank statement
                        addToTransactions("payment",srcAccIn,recipient,amount);
                    }
                    System.out.println("Current " + srcAccName + " balance: " + srcAccIn.getBalance());
                    break;
                }
                else{
                    System.out.println("Recipient doesn't have a checking account. Try another user. ");
                }
            }
            else{ //user doesn't exist
                System.out.println("Sorry user doesn't exist try another user.");
            }
            if(!verifyTransaction) { //asks if they want to try with another user
                System.out.println("\nWould you like to try another user?\n1. Yes \n2. No\n");
                System.out.print("Type your answer: ");
                String ans = UserInterface.catchExceptionsString(sc);

                if (ans.equals("2")) {
                    System.out.println("Returning to user transaction menu");
                    break;
                }
            }

        }
    }

    //Transaction Reader Methods

    /**
     * @author Laura Blanco
     * This methods pays another customer.
     * @param money Parameter of type double which amount to be payed
     * @param user Parameter of type Customer which lets us keep track of who we are paying
     * @param fromAcc Parameter of type string lets us know what account we are paying from
     * @param toAcc Parameter of type string lets us know what account we are paying to
     * @param isReader Parameter of type boolean that lets me know if the caller is the transaction reader
     */
    //Takes the parameters of how much money you will pay and the user you will pay to
    public void paySomeone(double money, Customer user, String toAcc, String fromAcc, boolean isReader){
        //also check for account number
        String denial;
        if(this.getFirstName().equals(user.getFirstName())){ //makes sure the user can't pay themselves
            denial = "Cannot pay yourself";
            System.out.println(denial);
            BankLog.failedTransaction(money,"pay",fromAcc,user,denial,this);
        }
        else if (money > this.getCheck().getBalance() || money > this.getSaving().getBalance()){ //checks from the beginning that we have sufficient funds
            if(this.getCheck().isHasAccount()) {
                denial = "Unable to pay due to insufficient funds";
                System.out.println(denial);
                BankLog.failedTransaction(money,"pay",fromAcc,user,denial,this);
            }else{
                denial = "You don't have a checking account you can't pay someone else";
                System.out.println(denial);
                BankLog.failedTransaction(money,"pay",fromAcc,user,denial,this);
            }
        }
        else if(money < 0){
            denial = "Invalid number you can not pay negative values";
            System.out.println(denial);
            BankLog.failedTransaction(money,"pay",fromAcc,user,denial,this);
        }
        else{
            if(fromAcc.equals("Checking")){ //checks what account we are paying from
                if (toAcc.equals("Savings")) { //checks what account we are paying to
                    user.getSaving().setBalance(user.getSaving().getBalance() + money); //updates the balance of the user you paid
                    //transactionToOthers(money, user); //calls transaction method to log it in
                    double updatedB = this.getCheck().getBalance() - money;
                    this.getCheck().setBalance(updatedB); //updates the balance
                    if (!isReader) { //only prints success if its not the transaction reader
                        System.out.println("Successfully paid " + money + " to " + user.getFirstName() + " " + user.getLastName());
                        System.out.println("Your current balance is now: " + this.getCheck().getBalance());
                    }
                    //Add transaction to array for bank statement
                    addToTransactions("payment", this.getCheck(), user, money);
                    BankLog.successfulTransactions(money, "payed",fromAcc,toAcc, user,this);
                } else {
                    if(user.getCheck().isHasAccount()) {
                        user.getCheck().setBalance(user.getCheck().getBalance() + money); //updates the balance of the user you paid
                        //transactionToOthers(money, user); //calls transaction method to log it in
                        double updatedB = this.getCheck().getBalance() - money;
                        this.getCheck().setBalance(updatedB); //updates the balance
                        if (!isReader) { //only prints success if its not the transaction reader
                            System.out.println("Successfully paid " + money + " to " + user.getFirstName() + " " + user.getLastName());
                            System.out.println("Your current balance is now: " + this.getCheck().getBalance());
                        }
                        //Add transaction to array for bank statement
                        addToTransactions("payment", this.getCheck(), user, money);
                        BankLog.successfulTransactions(money, "payed",fromAcc,toAcc, user,this);
                    }
                    else{
                        denial = "Sorry " + user.getFirstName() + " doesn't have a checking account";
                        System.out.println(denial);
                        BankLog.failedTransaction(money,"pay",fromAcc,user,denial,this);
                    }
                }

            } else if(fromAcc.equals("Savings")){ //checks what account we are paying from it can only be from checking or savings not credit
                if(toAcc.equals("Savings")){ //checks what account we are paying to
                    user.getSaving().setBalance(user.getSaving().getBalance()+ money); //updates the balance of the user you paid
                    //transactionToOthers(money,user); //calls transaction method to log it in
                    double updatedB = this.getSaving().getBalance() - money;
                    this.getSaving().setBalance(updatedB); //updates the balance
                    if(!isReader) {  //only prints success if its not the transaction reader
                        System.out.println("Successfully paid " + money + " to " + user.getFirstName() + " " + user.getLastName());
                        System.out.println("Your current balance is now: " + this.getSaving().getBalance());
                    }
                    //Add transaction to array for bank statement
                    addToTransactions("payment", this.getSaving(), user, money);
                    BankLog.successfulTransactions(money, "payed",fromAcc,toAcc, user,this);
                }else{ //if its not savings then it must be checking we cannot pay to a credit account
                    if(user.getCheck().isHasAccount()) {
                        user.getCheck().setBalance(user.getCheck().getBalance() + money); //updates the balance of the user you paid
                        //transactionToOthers(money,user); //calls transaction method to log it in
                        double updatedB = this.getSaving().getBalance() - money;
                        this.getSaving().setBalance(updatedB); //updates the balance
                        if(!isReader) {  //only prints success if its not the transaction reader
                            System.out.println("Successfully paid " + money + " to " + user.getFirstName() + " " + user.getLastName());
                            System.out.println("Your current balance is now: " + this.getSaving().getBalance());
                        }
                        //Add transaction to array for bank statement
                        addToTransactions("payment", this.getSaving(), user, money);
                        BankLog.successfulTransactions(money, "payed",fromAcc,toAcc, user,this);
                    }else{
                        denial = "You can't pay " + user.getFirstName() + " they don't have a checking account";
                        System.out.println(denial);
                        BankLog.failedTransaction(money,"pay",fromAcc,user,denial,this);
                    }
                }
            }
        }
    }

    /**
     * @author Laura Blanco
     * This methods completes transfers between accounts
     * @param money Parameter of type double which amount to be payed
     * @param fromAcc Parameter of type string lets us know what account we are paying from
     * @param toAcc Parameter of type string lets us know what account we are paying to
     * @param isReader Parameter of type boolean that lets me know if the caller is the transaction reader
     */
    public void transfer(double money, String fromAcc, String toAcc,boolean isReader){  // transfers money from accounts
        //paying from checking transferring to savings
        String denial;
        if (money < 0){ //doesn't allow for transferring of negative number
            denial = "Invalid number you can not transfer negative values";
            System.out.println(denial);
            BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
        }
        else if(fromAcc.equals("Checking")) {
            if (this.getCheck().isHasAccount()) {
                if ((this.getCheck().getBalance() - money) >= 0) { //if after subtracting the money we have a positive balance it continues
                    if (toAcc.equals("Credit")) {
                        if(this.getCredit().isHasAccount()) {
                            if ((this.getCredit().getBalance() + money) <= 0) {  //makes sure transferring money to account is valid
                                this.getCredit().setBalance(this.getCredit().getBalance() + money); //sets the new balance of credit
                                this.getCheck().setBalance(this.getCheck().getBalance() - money); //sets new blanace of checking
                                if (!isReader) {  //only prints success if its not the transaction reader
                                    System.out.println("Successfully transferred: " + money);
                                    System.out.println("New account balance in Checking: " + this.getCheck().getBalance());  //prints what was performed
                                    System.out.println("New account balance in Credit: " + this.getCredit().getBalance());
                                }
                                //Add transaction to array for bank statement
                                addToTransactions("transfer",this.getCheck(), this.getCredit(), money);
                                BankLog.successfulTransactions(money,"transferred","checking","credit",this,this);
                            } else {
                                denial = "Unable to transfer: " + money + " you can't pay more than what is in the balance";
                                System.out.println(denial);
                                BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
                            }
                        }
                        else{
                            denial = "Sorry you don't have a credit account you can't transfer to it.";
                            System.out.println(denial);
                            BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
                        }
                    } else if (toAcc.equals("Savings")) { // since saving account doesn't have requirements we can automatically transfer
                        this.getSaving().setBalance(this.getSaving().getBalance() + money); //updates balances for both accounts
                        this.getCheck().setBalance(this.getCheck().getBalance() - money);
                        if (!isReader) {
                            System.out.println("Successfully transferred: " + money);
                            System.out.println("New account balance in Checking: " + this.getCheck().getBalance());  //prints what was performed
                            System.out.println("New account balance in Savings: " + this.getSaving().getBalance());
                        }
                        //Add transaction to array for bank statement
                        addToTransactions("transfer",this.getCheck(), this.getSaving(), money);
                        BankLog.successfulTransactions(money,"transferred","checking","saving",this,this);
                    }
                } else {
                    denial = "Unable to transfer: " + money + " insufficient funds.";
                    System.out.println(denial);
                    BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
                }

            }
            else{
                denial = "Sorry you don't have a checking account you can't transfer";
                System.out.println(denial);
                BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
            }
        }
        else { //doesn't allow any other accounts only checking and saving
          if ((this.getSaving().getBalance() - money) >= 0) {  //if after subtracting the money we have a positive balance it continues
              if(toAcc.equals("Credit")){
                  if(this.getCredit().isHasAccount()) {
                      if ((this.getCredit().getBalance() + money) <= 0) {  //makes sure transferring money to account is valid
                          this.getCredit().setBalance(this.getCredit().getBalance() + money);
                          this.getSaving().setBalance(this.getSaving().getBalance() - money);
                          if (!isReader) {  //only prints success if its not the transaction reader
                              System.out.println("Successfully transferred: " + money);
                              System.out.println("New account balance in Saving: " + this.getSaving().getBalance());  //prints what was performed
                              System.out.println("New account balance in Credit: " + this.getCredit().getBalance());
                          }
                          //Add transaction to array for bank statement
                          addToTransactions("transfer",this.getSaving(), this.getCredit(), money);
                          BankLog.successfulTransactions(money,"transferred","saving","checking",this,this);
                      } else {
                          denial = "Unable to transfer: " + money + " you can't pay more than what is in the balance";
                          System.out.println(denial);
                          BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
                      }
                  }else{
                      denial = "Sorry you don't have a credit account you can't transfer.";
                      System.out.println(denial);
                      BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
                  }
              }
              else if(toAcc.equals("Checking")) {
                  if(this.getCheck().isHasAccount()) {
                      this.getCheck().setBalance(this.getCheck().getBalance() + money);
                      this.getSaving().setBalance(this.getSaving().getBalance() - money);
                      if (!isReader) {  //only prints success if its not the transaction reader
                          System.out.println("Successfully transferred: " + money);
                          System.out.println("New account balance in Savings: " + this.getSaving().getBalance());  //prints what was done
                          System.out.println("New account balance in Checking: " + this.getCheck().getBalance());
                      }
                      //Add transaction to array for bank statement
                      addToTransactions("transfer",this.getSaving(), this.getCheck(), money);
                      BankLog.successfulTransactions(money,"transferred","saving","checking",this,this);
                  }else{
                      denial = "Sorry you don't have a checking account.";
                      System.out.println(denial);
                      BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
                  }
              }
            } else {
                denial = "Unable to transfer: " + money + " insufficient funds.";
                System.out.println(denial);
                BankLog.failedTransaction(0,"transfer","checking",this,denial,this);
            }
        }
    }

    //Bank Statement Methods

    /**
     * @author Laura Blanco
     * @author Lidice Castro
     * Method adds a String to transactions array list that indicates what type of method the user executed.
     * @param transactionType String that indicates what type of transaction was executed by the user.
     * @param fromAccount Object of type Account of the user that's been used for the transaction.
     * @param toCustomer Object of type Account of the recipient that's been used for the transaction.
     * @param amount Parameter of type double that indicate the amount involved in the transaction.
     */
    public void addToTransactions(String transactionType, Account fromAccount, Customer toCustomer, double amount){
        String description = "";
        String[] temp = new String[8];
        //Round to two digits the amount and balance (for display)
        amount = Math.round(amount * 100.0) / 100.0;
        double balance = Math.round(fromAccount.getBalance() * 100.0) / 100.0;
        //According to the transaction type and the account assign their values into their respective position in the
        //array
        if(transactionType.toLowerCase().equals("payment")){
            description = "Payment - " + toCustomer.getFirstName() + " " + toCustomer.getLastName().charAt(0) + ".";
            //From acount of type Checking
            if(fromAccount.getName().equals("Checking")){
                temp[2] = "" + amount;
                temp[3] = "" + balance;
            }
            //From acount of type Savings
            else if(fromAccount.getName().equals("Savings")){
                temp[4] = "" + amount;
                temp[5] = "" + balance;
            }
            //From acount of type Credit
            else if(fromAccount.getName().equals("Credit")) {
                temp[6] = "" + amount;
                temp[7] = "" + balance;
            }
        }
        //Assign the date and the description to the array cell
        temp[0] = formatter.format(date);
        temp[1] = description;

        //Add array into the transaction array list
        this.transactions.add(temp);

    }

    /**
     * @author Laura Blanco
     * @author Lidice Castro
     * Method adds a String to transactions array list that indicates what type of method the user executed.
     * @param transactionType String that indicates what type of transaction was executed by the user.
     * @param fromAccount Object of type Account of the user that's been used for the transaction.
     * @param toAccount Object of type Account of the recipient that's been used for the transaction.
     * @param amount Parameter of type double that indicate the amount involved in the transaction.
     */
    public void addToTransactions(String transactionType, Account fromAccount, Account toAccount, double amount){

        String description = "";
        //Round to two digits the amount and balance (for display)
        String[] temp = new String[8];
        amount = Math.round(amount * 100.0) / 100.0;
        double balance = Math.round(fromAccount.getBalance() * 100.0) / 100.0;
        //According to the transaction type and the account assign their values into their respective position in the
        //array
        if(transactionType.toLowerCase().equals("transfer")){
            description = "Account Transfer";
            //From acount of type Checking
            if(fromAccount.getName().equals("Checking")){
                temp[2] = "" + amount;
                temp[3] = "" + balance;
            }
            //From acount of type Savings
            else if(fromAccount.getName().equals("Savings")){
                temp[4] = "" + amount;
                temp[5] = "" + balance;
            }
            //From acount of type Credit
            else if(fromAccount.getName().equals("Credit")) {
                temp[6] = "" + amount;
                temp[7] = "" + balance;
            }
            //Round balance from the recipient's account
            balance = Math.round(toAccount.getBalance() * 100.0) / 100.0;
            //To acount of type Checking
            if(toAccount.getName().equals("Checking")){
                temp[2] = "" + amount;
                temp[3] = "" + balance;
            }
            //To acount of type Savings
            else if(toAccount.getName().equals("Savings")){
                temp[4] = "" + amount;
                temp[5] = "" + balance;
            }
            //To acount of type Credit
            else if(toAccount.getName().equals("Credit")) {
                temp[6] = "" + amount;
                temp[7] = "" + balance;
            }
        }
        //Assign the date and the description to the array cell
        temp[0] = formatter.format(date);
        temp[1] = description;

        //Add array into the transaction array list
        this.transactions.add(temp);
    }

    /**
     * @author Laura Blanco
     * @author Lidice Castro
     * Method adds a String to transactions array list that indicates what type of method the user executed.
     * @param transactionType String that indicates what type of transaction was executed by the user.
     * @param account Object of type Account of the user that's been used for the transaction.
     * @param amount Parameter of type double that indicate the amount involved in the transaction.
     */
    public void addToTransactions(String transactionType, Account account, double amount){
        String description = "";
        //Round to two digits the amount and balance (for display)
        String[] temp = new String[8];
        amount = Math.round(amount * 100.0) / 100.0;
        double balance = Math.round(account.getBalance() * 100.0) / 100.0;
        //According to the transaction type and the account assign their values into their respective position in the
        //array
        if(transactionType.toLowerCase().equals("deposit")){
            description = "Deposit to";
        }
        else if(transactionType.toLowerCase().equals("withdrawal")){
            description = "Withdrawal from";
        }
        //From acount of type Checking
        if(account.getName().equals("Checking")){
            temp[2] = "" + amount;
            temp[3] = "" + balance;
        }
        //From acount of type Savings
        else if(account.getName().equals("Savings")){
            temp[4] = "" + amount;
            temp[5] = "" + balance;
        }
        //From acount of type Credit
        else if(account.getName().equals("Credit")) {
            temp[6] = "" + amount;
            temp[7] = "" + balance;
        }
        //Add array into the transaction array list
        temp[0] = formatter.format(date);
        temp[1] = description;

        //Add array into the transaction array list
        this.transactions.add(temp);
    }
}




