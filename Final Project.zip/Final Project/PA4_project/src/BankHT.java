/**
 * Class that holds the methods to generate hash tables ordered by name or account number.
 * @author Lidice Castro
 * @author Laura Blanco
 * @version 4, November 7, 2020
 */

import java.io.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Scanner;

public class BankHT {

    //ATTRIBUTES
    private String fileName;
    private Hashtable<String, Integer> headerHT;
    private Hashtable<String, Customer> usersByNameHT;
    private Hashtable<String, Customer> usersByCreditHT;
    private Hashtable<String, Customer> usersBySavingsHT;
    private Hashtable<String, Customer> usersByCheckingHT;
    private String header;

    //CONSTRUCTORS
    /**
     * Default constructor
     */
    public BankHT() { }

    /**
     *Constructor that takes as input the name of the csv file.
     * @param fileNameIn String that indicates the name of the file of the bank users.
     */
    public BankHT(String fileNameIn) {
        this.fileName = fileNameIn;
        //Initialize
        this.init();
    }

    //SETTERS AND GETTERS

    public Hashtable<String, Customer> getUsersByNameHT(){
        return this.usersByNameHT;
    }

    public Hashtable<String, Customer> getUsersByCheckingHT(){
        this.usersByCheckingHT = this.createAccountNumHT("Checking");
        return this.usersByCheckingHT;
    }

    public Hashtable<String, Customer> getUsersBySavingsHT(){
        this.usersBySavingsHT = this.createAccountNumHT("savings");
        return this.usersBySavingsHT;
    }

    public Hashtable<String, Customer> getUsersByCreditHT(){
        //Get's an updated version of the hash table
        this.usersByCreditHT = this.createAccountNumHT("credit");
        return this.usersByCreditHT;
    }

    //METHODS
    /**
     * @author Lidice Castro
     * The following method initializes the attributes in the class.
     */
    public void init() {
        try {
            this.header = this.copyHeader();
            this.headerToHT();
            this.usersByNameHT = this.bankUsersToHT("name");
            this.usersByCheckingHT = this.bankUsersToHT("checking");
            this.usersBySavingsHT = this.bankUsersToHT("savings");
            this.usersByCreditHT = this.bankUsersToHT("credit");
        } catch (FileNotFoundException e) {
            //In case of file not found, display the following exception message.
            System.out.print("FileNotFoundException: ");
            System.err.format("An error occurred while trying to read '%s'.\n", this.fileName);
            //Unsuccessful termination
            System.exit(1);
        }
    }

    /**
     * @author Lidice Castro
     * @return Returns a String that contains the header of the csv file.
     * Method that obtains the a copy of the header that contains the columns' names.
     * @throws FileNotFoundException
     */
    private String copyHeader() throws FileNotFoundException {
        //Variables and objects
        String temp;
        File bankUsersFile = new File(this.fileName);
        Scanner sc = new Scanner(bankUsersFile);
        //Read the header
        temp = sc.nextLine();
        //Close Scanner instance
        sc.close();
        return temp;
    }

    /**
     * @author Lidice Castro
     * Method that converts the header String into a hash table. It maps the name of the column (String)
     * as key and its respective column position (int) as value.
     */
    private void headerToHT() {
        //Variables and objects
        String temp;
        String[] tokens;
        //Assign the header to a temp variable
        temp = this.header;
        //Split the string into tokens using the ',' delimeter
        tokens = temp.split(",");
        //Create a HT to store the elements of the header with its number of column as key
        Hashtable<String, Integer> tempHT = new Hashtable<String, Integer>(tokens.length);
        //Add the elements to the hash table
        for (int i = 0; i < tokens.length; i++) {
            tempHT.put(tokens[i].toLowerCase(), i);
        }
        //Assign HT to the attribute headerHT
        this.headerHT = tempHT;
    }

    /**
     * @author Lidice Castro
     * Method that returns an integer that is the position of the column in the csv file.
     * @param key Parameter of type String that contains a key for search in the hash table.
     * @return Returns an integer that contains the position of the column name.
     */
    public int getHeaderColumn(String key) {
        return this.headerHT.get(key.toLowerCase());
    }

    /**
     * @author Lidice Castro
     * Method to get a value of a hash table according to the provided key
     * @param key String that contains the key for the hash table.
     * @param ht Hashtable where the value will be extracted.
     * @return Returns the value that corresponds to the key.
     */
    public Customer getUserInfo(String key, Hashtable<String, Customer> ht) {
        //Use get method of the hash table to obtain the value of a key
        return ht.get(key.toLowerCase());
    }

    /**
     * @author Lidice Castro
     * Method sets the conditions to generate a hash table according to the type indicated in the parameters.
     * The key changes according to the value of "htType".
     * @param htType String indicates what type of hash table will be created.
     * @return Returns resulting hash table
     * @throws FileNotFoundException
     */
    private Hashtable<String, Customer> bankUsersToHT(String htType) throws FileNotFoundException {
        //Variables and objects
        int keyColumn1 = 0, keyColumn2 = 0;
        Hashtable<String, Customer> tempHT = new Hashtable<String, Customer>();
        //Conditions look for the first and last names or account numbers that are the key for search in HT
        //Hash table ordered by user name
        if (htType.toLowerCase().equals("name")) {
            keyColumn1 = getHeaderColumn("First Name");
            keyColumn2 = getHeaderColumn("Last Name");
            tempHT = this.createHT(keyColumn1, keyColumn2);
        } else if (htType.toLowerCase().equals("checking")) { //Hash table ordered by checking number
            keyColumn1 = getHeaderColumn("checking account number");
            tempHT = this.createAccountNumHT("Checking");
        } else if (htType.toLowerCase().equals("savings")) {
            keyColumn1 = getHeaderColumn("savings account number"); //Hash table ordered by savings account number
            tempHT = this.createAccountNumHT("Savings");
        } else if (htType.toLowerCase().equals("credit")) {
            keyColumn1 = getHeaderColumn("credit account number"); //Hash table ordered by credit account number
            tempHT = this.createAccountNumHT("Credit");
        }
        //return hash table
        return tempHT;
    }

    /**
     * @author Lidice Castro
     * Method to create a hash table with a key composed of two words (two column values).
     * @param keyColumn1 Parameter that contains the first name.
     * @param keyColumn2 Parameter that contains the last name.
     * @return Returns the resulting hash table of the bank users.
     * @throws FileNotFoundException
     */
    private Hashtable<String, Customer> createHT(int keyColumn1, int keyColumn2) throws FileNotFoundException {
        //Variables and objects
        String temp, key;
        Hashtable<String, Customer> tempHT = new Hashtable<String, Customer>();
        //Create File and Scanner objects
        File bankUsersFile = new File(this.fileName);
        Scanner sc = new Scanner(bankUsersFile);
        temp = sc.nextLine();
        //Get column number for dob
        int dobCol = getHeaderColumn("Date of Birth".toLowerCase());
        //Get column number for address in the file.
        int addressCol = getHeaderColumn("Address".toLowerCase());
        //read all the users (rows) in the file
        while (sc.hasNext()) {
            //Get current user (row)
            temp = sc.nextLine();
            String[] tokens = new String[headerHT.size()];
            //Assign the address to its respective column in tokens array
            String[] tokensSplit1 = temp.split("\"");
            tokens[dobCol] = "\"" + tokensSplit1[1] + "\"";
            tokens[addressCol] = "\"" + tokensSplit1[3] + "\"";
            temp = tokensSplit1[0] + tokensSplit1[2] + tokensSplit1[4];
            //Split the rest of the columns using the "," separator
            String[] tokensSplit2 = temp.split(",", -2);
            //Assign the rest of the columns to its respective column in tokens
            for (int i = 0; i < headerHT.size(); i++) {
                if (i == addressCol || i == dobCol) {
                    continue;
                } else {
                    tokens[i] = tokensSplit2[i];
                }
            }
            //Get the key for HT
            key = tokens[keyColumn1] + tokens[keyColumn2];
            //Get Customer object
            Customer customer = createCustomerObject(tokens);
            //Add user info to HT
            tempHT.put(key.toLowerCase(), customer);
        }
        //Close instance of the Scanner object
        sc.close();
        //Return hashtable
        return tempHT;
    }

    /**
     * @author Lidice Castro
     * Method to create a hash table with a key composed of a single word (one column values).
     * @param accType String indicates what kind of account will be used to construct the hash table.
     * @return Returns the resulting hash table of the bank users.
     */
    private Hashtable<String, Customer> createAccountNumHT(String accType){
        //Variables and objects
        String newKey = "";
        //Get the keys from the hash table which keys are by name
        String[] keys = this.usersByNameHT.keySet().toArray(new String[0]);
        Hashtable<String, Customer> tempHT = new Hashtable<String, Customer>();
        for(String key: keys){
            //Gets the value according to key from the hash table ordered by name
            Customer user = getUserInfo(key,this.usersByNameHT);
            //Construct a new hash table with account number as key
            if(accType.toLowerCase().equals("savings")){
                Savings acc = user.getSaving();
                newKey = "" + acc.getAccountNumber();
            }
            else if(accType.toLowerCase().equals("checking")){
                Checking acc = user.getCheck();
                newKey = "" + acc.getAccountNumber();
            }
            else if(accType.toLowerCase().equals("credit")){
                Credit acc = user.getCredit();
                newKey = "" + acc.getAccountNumber();
            }
            //Add user info to HT
            tempHT.put(newKey, user);
        }
        //Return hashtable
        return tempHT;
    }

    /**
     * @author Lidice Castro
     * Method that creates a Customer object by filling its constructor with the information obtained from the csv.
     * @param userInfo Array of Strings that contain the information extracted from the csv.
     * @return Returns a Customer object
     */
    private Customer createCustomerObject(String[] userInfo) {
        //Assign each column to its value
        String firstName = userInfo[this.getHeaderColumn("First Name")];
        String lastName = userInfo[this.getHeaderColumn("last name")];
        String dob = userInfo[this.getHeaderColumn("Date of Birth")];
        int ID = Integer.parseInt(userInfo[this.getHeaderColumn("Identification Number")]);
        String phoneNumber = userInfo[this.getHeaderColumn("Phone Number")];
        String address = userInfo[this.getHeaderColumn("Address")];
        String password = userInfo[this.getHeaderColumn("Password")];
        String email = userInfo[this.getHeaderColumn("Email")];
        int checkingAccNum = Integer.parseInt(userInfo[this.getHeaderColumn("checking account number")]);
        double checkingBalance = Double.parseDouble(userInfo[this.getHeaderColumn("Checking Starting Balance")]);
        int creditAccNum = Integer.parseInt(userInfo[this.getHeaderColumn("credit account number")]);
        double creditBalance = Double.parseDouble(userInfo[this.getHeaderColumn("Credit Starting Balance")]);
        double creditMax = Double.parseDouble(userInfo[this.getHeaderColumn("Credit Max")]);
        int savingsAccNum = Integer.parseInt(userInfo[this.getHeaderColumn("savings account number")]);
        double savingsBalance = Double.parseDouble(userInfo[this.getHeaderColumn("Savings Starting Balance")]);

        //uses customer constructor to create a new instance of customer
        Customer account = (new Customer(firstName, lastName, dob, ID, address, phoneNumber, password, email,
                new Checking(checkingAccNum,checkingBalance,true),
                new Savings(savingsAccNum,savingsBalance,true),
                new Credit(creditAccNum,creditBalance, creditMax,true)));

        account.setSavBegBal(savingsBalance);
        account.setCheckBegBal(checkingBalance);
        account.setCredBegBal(creditBalance);

        return account;
    }

    /**
     * @author Laura Blanco
     * This methods writes the updated users csv file
     * @param accounts Parameter of type Hashtable Customer that holds all the customer objects
     */
    public void writeData(Hashtable<String ,Customer> accounts) //will write a new csv file with updated balances and users
    {
        ArrayList<String> arrTemp = new ArrayList<>();
        String updatedName = "BankUsers updated.csv";
        File file = new File(updatedName);
        try {
            FileWriter fw = new FileWriter(file, false);   // create FileWriter object with file as parameter
            PrintWriter pw = new PrintWriter(fw);

            String [] header = {"First Name", "Last Name", "Date of Birth", "Identification Number", "Address","Phone Number", "Checking Starting Balance",
                    "Checking Account Number", "Savings Starting Balance", "Savings Account Number","Credit Starting Balance", "Credit Account Number", "Credit Max", "Email", "Password"  };
            pw.println(String.join(",", header));  //prints the first line onto the file

            for (Customer customer : accounts.values()) { //for every item in the customer list it will print their information into it
                String[] info = allInfo(customer); //calls helper method to get information for specific user
                pw.println(String.join(",", info)); //joins the information with a comma
            }
            pw.close(); //closes file

        }
        catch (FileNotFoundException exception) { //catches error if file isn't found
            System.out.println("File was not found");
            System.exit(0);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @author Laura Blanco
     * Helper method that returns all the user information given the user
     * @param user Parameter of type Customer that hold the current customer
     * @return String[] which has all attributes of user
     */
    public static String[] allInfo(Customer user){  // will get all the information from the user


        String first = user.getFirstName();  //uses getters to retrieve the information of the user
        String last = user.getLastName();
        String dob = user.getDOB();
        String IdentityNum = Integer.toString(user.getIdentificationNum());
        String address = user.getAddress();
        String phone = user.getPhoneNum();
        String checkBal = Double.toString(user.getCheck().getBalance()); //parses values back to string in order to be put into csv
        String checkNum = Integer.toString(user.getCheck().getAccountNumber());
        String savBal = Double.toString(user.getSaving().getBalance());
        String savNum = Integer.toString(user.getSaving().getAccountNumber());
        String credBal = Double.toString(user.getCredit().getBalance());
        String credNum = Integer.toString(user.getCredit().getAccountNumber());
        String credMax = Double.toString(user.getCredit().getMaxBal());
        String password = user.getPassword();
        String email = user.getEmail();

        return new String[]{first,last,dob,IdentityNum,address,phone,checkBal,checkNum,savBal,savNum,credBal,credNum,credMax,email,password}; //returns information for one user
    }

}