/**
 * Abstract class that holds the person that is not a customer.
 * @author Laura Blanco
 * @version 4, November 7,2020
 */

public abstract class Person {
    //ATTRIBUTES
    private String firstName;
    private String lastName;

    //CONSTRUCTORS
    public Person(){  //default constructor

    }

    /**
     * This constructor will set the first and last name of a person
     * @param firstNameIn Parameter is the name of person
     * @param lastNameIn Parameter is the last name of person
     */
    public Person(String firstNameIn, String lastNameIn){  //child will use these values
        this.firstName = firstNameIn;
        this.lastName = lastNameIn;
    }

    //SETTERS AND GETTERS

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

}
