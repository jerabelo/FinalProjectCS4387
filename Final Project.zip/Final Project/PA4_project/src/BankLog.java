/**
 * Class that holds the Bank Log generated in each session.
 * @author Laura Blanco
 * @author Lidice Castro
 * @version 1, November 8, 2020
 */

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class BankLog implements Printable{

    //ATTRIBUTES
    private static ArrayList<String> bankLog = new ArrayList<>();
    private final String fileName = "Banklog.txt";

    //CONSTRUCTORS
    /**
     * Default constructor
     */
    public BankLog(){
    }

    /**
     * @author Lidice Castro
     * This method creates a new file to write transaction logs.
     */
    public void createFile() {
        try{
            FileWriter fw = new FileWriter (this.fileName, false);   //creates a new file under the filename
            PrintWriter pw = new PrintWriter(this.fileName);
            pw.print("");  //clears the file
            pw.close();
        }
        catch(IOException e){  //catches exception if it can't write to file
            System.out.print("IOException: ");
            System.err.format("An error occurred while trying to write '%s'.\n", this.fileName);
        }
    }

    /**
     * @author Laura Blanco
     * @author Lidice Castro
     * This methods writes to the file previously created
     * @return A boolean value to indicate if the the operation of print was successful or not.
     */
    public boolean print(){

        try(FileWriter fw = new FileWriter(this.fileName, true); //Creates a file if it hasn't been created otherwise just writes to it
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter p = new PrintWriter(bw)) { //to append to file
            printTransactions(p);
            p.close();
            return true; //returns true for successful completion

        } catch (IOException e) { //Catches exception if it cannot write to file
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        return false;
    }

    /**
     * @author Laura Blanco
     * This methods prints the transactions to the file
     * @param pw Parameter of type PrintWriter that holds the print writer
     */

    public void printTransactions(PrintWriter pw) {

        for( String string : bankLog){  //for every string in the array it prints it to the file
            pw.println(string);
        }


    }

    /**
     * @author Laura Blanco
     * This methods logs transactions one person does
     * @param money Parameter of type double which amount to be payed
     * @param action Parameter of type String lets us know what action we did
     * @param accountType Parameter of type String lets us know what account we will perform the transaction on
     * @param user Parameter of type Customer that holds the user to pay if that is the action
     * @param loggedIn Parameter of type Customer that holds the current user logged in that is trying to perform actions
     * @param destination Parameter of type String that tells me the destination account
     */
    public static void successfulTransactions(double money, String action, String accountType, String destination, Customer user, Customer loggedIn){ //logs transactions within itself into log
        String transaction = "";
        action = action.toLowerCase();
        accountType = accountType.toLowerCase();
        destination = destination.toLowerCase();
        //checks the action and account type to determine what print statement to add to the array list
        if ((action.equals("deposited")) && (accountType.equals("checking"))){  //if statements to check what action we will be logging on the transaction file
            transaction = loggedIn.getFirstName() + " " + loggedIn.getLastName() + " " + action + " " + money + " new checking balance is: " + loggedIn.getCheck().getBalance();  //uses the action and money parameters to make thing simpler
        }
        else if ((action.equals("deposited")) && (accountType.equals("saving"))){
            transaction = loggedIn.getFirstName() + " " + loggedIn.getLastName() + " " + action + " " + money + " new saving balance is: " + loggedIn.getSaving().getBalance();
        }
        else if ((action.equals("deposited")) && (accountType.equals("credit"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " " + action + " " + money + " new credit balance is: " + loggedIn.getCredit().getBalance(); //prints statements change according to what the action and account are
        }
        else if ((action.equals("withdrew")) && (accountType.equals("checking"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " " + action + " " + money + " new checking balance is: " + loggedIn.getCheck().getBalance();
        }
        else if ((action.equals("withdrew")) && (accountType.equals("saving"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " " + action + " " + money + " new saving balance is: " + loggedIn.getSaving().getBalance();
        }
        else if ((action.equals("inquiry")) && (accountType.equals("saving"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " made an " + action + " on savings, account balance is: " + loggedIn.getSaving().getBalance();
        }
        else if ((action.equals("inquiry")) && (accountType.equals("checking"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " made an " + action + " on checking, account balance is: " + loggedIn.getCheck().getBalance();
        }
        else if ((action.equals("inquiry")) && (accountType.equals("credit"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " made an " + action + " on credit, account balance is: " + loggedIn.getCredit().getBalance();
        }
        else if ((action.equals("transferred")) && (accountType.equals("checking"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " " + action + " " + money + " from "+ accountType + " to " + destination + " new checking balance is: " + loggedIn.getCheck().getBalance();
        }
        else if ((action.equals("transferred")) && (accountType.equals("saving"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " " + action + " " + money + " from "+ accountType + " to " + destination + " new saving balance is: " + loggedIn.getSaving().getBalance();
        }
        else if(action.equals("payed")){
            transaction = loggedIn.getFirstName() + " " + loggedIn.getLastName() + " payed " + money + " to " + user.getFirstName() + " " + user.getLastName(); //writes this line on the file
        }

        //adds statement to array list
        bankLog.add(transaction);
    }

    /**
     * @author Laura Blanco
     * This method logs failed transactions to bank log file
     * @param money Parameter of type double that holds the amount
     * @param action Parameter of type String that holds the action the user performed
     * @param accountType Parameter of type String that holds the account the user wanted to perform a transaction on
     * @param user Parameter of type Customer that holds the user to pay if that is the action
     * @param reason Parameter of type String that holds the reason for the failed transaction
     * @param loggedIn Parameter of type Customer that holds the current user logged in that is trying to perform actions
     */
    public static void failedTransaction(double money, String action, String accountType, Customer user, String reason, Customer loggedIn){
        //Variable to set the sentence to
        String transaction = "";
        action = action.toLowerCase();
        accountType = accountType.toLowerCase();
        if ((action.equals("deposited"))){  //if statements to check what action we will be logging on the transaction file
            transaction = loggedIn.getFirstName() + " " + loggedIn.getLastName() + " failed to deposit " + money + " to " + accountType + ". " + reason;
        }
        else if ((action.equals("withdraw"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " failed to " + action + " " + money + " from " + accountType + ". " + reason;
        }
        else if((action.equals("transfer")) && (money == 0)){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " failed to " + action + " to " + accountType + ". " + reason;
        }
        else if ((action.equals("transfer"))){
            transaction =loggedIn.getFirstName() + " " + loggedIn.getLastName() + " failed to " + action + " " + money + " to " + accountType + ". " + reason;
        }
        else if(action.equals("pay")) {
            transaction = loggedIn.getFirstName() + " " + loggedIn.getLastName() + " failed to " + action + " " + money + " to " + user.getFirstName() + " " + user.getLastName() + ". " + reason;
        }

        //adds statement to array list
        bankLog.add(transaction);
        }
}
