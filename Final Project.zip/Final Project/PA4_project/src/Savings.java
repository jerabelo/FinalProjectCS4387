/**
 * Class that holds the saving account balance and number and inherits from account class.
 * @author Laura Blanco
 * @version 4, November 7,2020
 */

public class Savings extends Account{

    //CONSTRUCTORS
    public Savings (){
        super();
    } //calls parent class

    /**
     * This constructor will set the account number and balance
     * @param accountNumberIn Parameter is the account number of saving account
     * @param balanceIn Parameter is the balance of saving account
     * @param hasAccount Parameter that determines whether the user has this type of account
     */
    public Savings( int accountNumberIn,double balanceIn, boolean hasAccount){ //constructor to set the attributes of the object
        super(accountNumberIn,balanceIn,hasAccount,"Savings");
    }

}
