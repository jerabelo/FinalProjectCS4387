/**
 * Class that holds the saving account balance and number and inherits from account class.
 * @author Lidice Castro
 * @version 3, September 29,2020
 */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.InputMismatchException;
import java.util.Scanner;

public class UserInterface {

    //ATTRIBUTES
    private Hashtable<String, Customer> bankUsersHT;

    //CONSTRUCTORS
    public UserInterface() {
        //Default constructor
    }

    public UserInterface(Hashtable<String, Customer> ht) {
        this.bankUsersHT = ht;
    }

    //METHODS
    /**
     * @author Lidice Castro
     * This method will ask the user who they are.
     * @return Returns value of type integer that contains the user type (customer or manager).
     */
    public int selectUserType() {
        //Variables and objects
        Scanner sc = new Scanner(System.in);
        int selectionNum;
        //Display instruction to select transaction
        System.out.println("1. Customer\n2. Bank Manager\n3. Transaction Reader\n4. Exit");
        //Scan the option the user selects
        selectionNum = this.catchExceptionsInt(sc, 4); //calls method to catch exceptions of a different answer
        return selectionNum;
    }

    /**
     * @author Laura Blanco
     * This methods catches exception of type int.
     * @param in Parameter of type Scanner
     * @return int
     */
    public int catchExceptionsInt(Scanner in, int totalOptions) { //Catches inputs other than integers
        int value;
        while (true) {
            try {
                System.out.print("\nType your answer: ");
                value = in.nextInt();  //will prompt the user to enter a value
                if (value > 0 && value <= totalOptions) {
                    break;
                } else {
                    System.out.println("\nOption not in the menu try again please");
                }

            } catch (InputMismatchException e) {  //catches if the value is not an integer
                System.out.println("\nInvalid input. Integer values only please.");
                in.nextLine(); //will prompt the user to enter again until value is valid
            }
        }
        return value;
    }

    /**
     * @author Laura Blanco
     * This method will catch exceptions if the number entered is not an integer.
     * @param in Parameter of type scanner that will scan the user input.
     * @return int
     */
    public int catchExceptionsInt(Scanner in){ //Catches inputs other than integers
        int value;
        while(true) {
            try {
                value = in.nextInt();  //will prompt the user to enter a value
                break;

            } catch (InputMismatchException e) {  //catches if the value is not an integer
                System.out.println("Invalid input. Integer values only please.");
                in.nextLine(); //will prompt the user to enter again until value is valid
            }
        }
        return value;
    }

    /**
     * @author Laura Blanco
     * @author Lidice Castro
     * This method will determine if the user exists.
     * @return Returns a value of type String that represents the object of the user.
     */
    public Customer userAuthenticationPage(){
        //Variables and objects
        Customer savedAcc;
        String firstName, lastName, key;
        Scanner sc = new Scanner(System.in);

        //User authentication window
        for(;;) {
            //Enter first name
            System.out.print("Enter first Name: ");
            firstName = catchExceptionsString(sc);

            //Enter last name
            System.out.print("Enter last Name: ");
            lastName = catchExceptionsString(sc);

            //Create key
            key = firstName + lastName;

            //Break loop if user exists.
            if(this.bankUsersHT.containsKey(key.toLowerCase())){ //looks for key in hash table
                savedAcc = this.bankUsersHT.get(key.toLowerCase());
                break;
            }
            else{
                System.out.println("Not a valid account try again");
            }
        }

        //Return the user object
        return savedAcc;
    }

    /**
     * @author Laura Blanco
     * This method makes sure the password is correct.
     * @param account Parameter of type Customer that holds the customer object account to verify password.
     * @return boolean if password is correct.
     */
    public boolean passwordVerify(Customer account){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter password: ");
        String password = catchExceptionsString(sc);
        if(account.getPassword().equals(password)){ //compares the password input to the password saved
            return true;
        }
        System.out.println("Invalid password returning to main menu"); //if they don't match it returns to menu
        return false;
    }

    /**
     * @author Laura Blanco
     * This methods catches exception of type String.
     * @param in Parameter of type Scanner.
     * @return String
     */
    public static String catchExceptionsString(Scanner in){ //Catches inputs other than integers
        String val = "";
        try {
            val = in.nextLine();
        } catch (InputMismatchException e) { //catches if value is not a string
            System.out.println("Invalid input. String only please. ");
        }
        return val;
    }

    /**
     * @author Lidice Castro
     * This method asks the user to enter what transaction they want to perform.
     * @return Returns a value of type integer that represents the transaction selected by the customer.
     */
    public int selectCustomerTransaction(){
        System.out.println("----------------------------------------------------------------\n");
        System.out.println("USER TRANSACTION MENU");
        //Variables and objects
        int selectionNum;
        Scanner sc = new Scanner(System.in);

        System.out.println(" 1. Check balance\n 2. Make a deposit\n 3. Transfer money\n 4. Pay someone\n 5. Withdraw money\n 6. Return to main menu");
        //catch exception for invalid input or out of range in menu
        selectionNum = catchExceptionsInt(sc,6);
        return selectionNum;
    }

    /**
     * @author Lidice Castro
     * This method will print the accounts the user can choose from and ask for an answer.
     * @param transactionNum Parameter of type integer that represents the number of transaction in the menu.
     * @param hasChecking Parameter of type boolean that determines if user has checking account.
     * @param hasSavings Parameter of type boolean that determines if user has savings account.
     * @param hasCredit Parameter of type boolean that determines if user has credit account.
     * @return Returns a value of type String that contains the type of account (Checking, Savings or Credit) according to the type of transaction.
     */
    public String selectAccount(int transactionNum, boolean hasChecking, boolean hasSavings, boolean hasCredit){

        //Variables and objects
        int selectionNum;
        ArrayList<String> arrTemp = new ArrayList<>();  //array list that will hold the type of accounts the user has
        Scanner sc = new Scanner(System.in);
        String[] temp;

        //Prompt user to select a transaction
        System.out.println("----------------------------------------------------------------\n");
        //Display instruction to select an account
        if(transactionNum == 1 || transactionNum == 2) {
            //Prompt the user to select account
            System.out.println("Select account: ");
            if(hasChecking){
                arrTemp.add("Checking");
            }
            if(hasSavings){
                arrTemp.add("Savings");
            }
            if(hasCredit){
                arrTemp.add("Credit");
            }
        }
        else{
            //Promp the user to select an account for transfer
            if(transactionNum == 3){
                System.out.println("From which account would you like to transfer?\n");
            }
            else{
                System.out.println("Select account to complete transaction from: ");
            }
            if(hasChecking){
                arrTemp.add("Checking");
            }
            if(hasSavings){
                arrTemp.add("Savings");
            }

        }
        temp = new String[arrTemp.size()];
        temp = arrTemp.toArray(temp);

        //Clear array list
        arrTemp.clear();

        //Display options
        for(int i = 0; i < temp.length; i++){
            System.out.println((i+1) + ". " + temp[i]);
        }
        //User input
        selectionNum = catchExceptionsInt(sc,temp.length);
        System.out.println();

        //Return number of the transaction selected
        return temp[selectionNum-1];
    }

    /**
     * @author Lidice Castro
     * This method will print the options the user has to perform transactions
     * @param srcAccount Parameter of type String that represents the transaction in the menu.
     * @param hasChecking Parameter of type boolean that determines if user has checking account.
     * @param hasSavings Parameter of type boolean that determines if user has savings account.
     * @param hasCredit Parameter of type boolean that determines if user has credit account.
     * @return Returns a value of type String that contains the type of account (Checking, Savings or Credit) according to the type of transaction.
     */
    public String selectToWhichAccount(String srcAccount, boolean hasChecking, boolean hasSavings, boolean hasCredit){
        //Variables and objects
        int selection;
        ArrayList<String> arrTemp = new ArrayList<>(); //array list that will hold the type of accounts the user has
        String[] temp = new String[3];
        Scanner sc = new Scanner(System.in);

        //Prompt user to select a transaction
        System.out.println("\n----------------------------------------------------------------\n");
        System.out.println("Choose account: \n");

        if(srcAccount.equals("Checking")){
            if(hasSavings){
                arrTemp.add("Savings");
            }
            if(hasCredit){
                arrTemp.add("Credit");
            }

            temp = new String[arrTemp.size()];
            temp = arrTemp.toArray(temp);
        }
        else if(srcAccount.equals("Savings")){
            if(hasChecking){
                arrTemp.add("Checking");
            }
            if(hasCredit){
                arrTemp.add("Credit");
            }

            temp = new String[arrTemp.size()];
            temp = arrTemp.toArray(temp);
        }

        //Clear array list
        arrTemp.clear();

        //Display options
        for(int i = 0; i < temp.length; i++){
            System.out.println((i+1) + ". " + temp[i]);
        }
        //User input
        selection = catchExceptionsInt(sc,temp.length);
        System.out.println("\n----------------------------------------------------------------\n");
        System.out.println();

        //Return number of the transaction selected
        return temp[selection-1];
    }

    /**
     * @author Laura Blanco
     * This method displays the options in the bank manager menu and does the logic to execute the trasaction that was selected.
     * @param bht parameter of type hash table
     * @param bkm paramater of type class bank manager model
     */
    public void selectManagerTransaction(BankHT bht, BankManagerModel bkm){
        int userAccount;
        Customer savedAccount = new Customer();
        String key;
        Scanner scInt = new Scanner(System.in);

        do {  //do while to perform the prompts at least once
            System.out.println("----------------------------------------------------------------");
            System.out.println("BANK MANAGER MENU\n");
            System.out.println("Please select from the following: ");
            System.out.println("1. Inquire account by name");
            System.out.println("2. Inquire account by type/number");
            System.out.println("3. Print all accounts");
            System.out.println("4. Write a bank statement");
            System.out.println("5. Create new user");
            System.out.println("6. Return to main menu");
            userAccount = catchExceptionsInt(scInt,6);

            if (userAccount == 1) {    //bank manger wants to know about an account by their name
                while(true){
                    key = askForKey("name");
                    if(verifyKey(this.bankUsersHT,key)){
                        System.out.println();
                        System.out.println("----------------------------------------------------------------");
                        savedAccount = bht.getUserInfo(key,this.bankUsersHT);
                        bkm.printInquiredInfo(savedAccount);//calls helper method to print all information for found user
                        break;
                    }
                    else{
                        if(!this.tryAnotherUser()){
                            break;
                        }
                    }
                }
            }
            else if (userAccount == 2) { //bank manger wants to know about an account by their account number

                System.out.println("\nChoose the account type");
                System.out.println("1. Checking");
                System.out.println("2. Savings");
                System.out.println("3. Credit");
                int accChoice = catchExceptionsInt(scInt,3);
                while (true) {   //infinite loop that won't end until user inputs valid input
                    //Create the hash table objects ordered by account number
                    Hashtable<String,Customer> bankUsersByChecking = bht.getUsersByCheckingHT();
                    Hashtable<String,Customer> bankUsersBySavings = bht.getUsersBySavingsHT();
                    Hashtable<String,Customer> bankUsersByCredit = bht.getUsersByCreditHT();
                    Hashtable<String, Customer> tempHT = new Hashtable<>();
                    if (accChoice == 1) {
                        tempHT = bankUsersByChecking;
                    } else if (accChoice == 2) {
                        tempHT = bankUsersBySavings;
                    } else if (accChoice == 3) {
                        tempHT = bankUsersByCredit;
                    }
                    key = askForKey("account");

                    if (verifyKey(tempHT, key)) {
                        System.out.println();
                        System.out.println("----------------------------------------------------------------");
                        savedAccount = bht.getUserInfo(key, tempHT);
                        bkm.printInquiredInfo(savedAccount);//calls helper method to print all information for found user
                        break;
                    } else {
                        if(!this.tryAnotherUser()){
                            break;
                        }
                    }
                }
            } else if (userAccount == 3) {  //bank manger wants to print information of all accounts
                System.out.println();
                for (Customer customer : this.bankUsersHT.values()) {  //for loop will iterate through entire list
                    System.out.println("----------------------------------------------------------------");
                    savedAccount = customer;
                    bkm.printInquiredInfo(savedAccount); //helper method is called in each iteration to print every user information
                }
            } else if (userAccount == 4) { //bank manager wants to create a bank statement for a user
                key = askForKey("name");

                if(verifyKey(this.bankUsersHT,key)){
                    System.out.println();
                    System.out.println("----------------------------------------------------------------");
                    savedAccount = bht.getUserInfo(key,this.bankUsersHT);
                    bkm.createStatement(savedAccount); //calls helper method to create the bank statement for the specific user*/
                    break;
                }
                else{
                    if(!this.tryAnotherUser()){
                        break;
                    }
                }
            }
            else if(userAccount == 5){
                bkm.newUser(this.bankUsersHT); //calls helper method that will create a new user
            }
            else if (userAccount == 6) { //will return to menu if user inputs this otherwise will continue in this do while
                System.out.println("Returning to main menu...");
                break;
            }
        } while (true);
    }

    /**
     * @author Lidice Castro
     * Method asks for the information required to create the key according to the type of inquire.
     * @param type String that indicates if the key will be by name or account.
     * @return Returns a String that contains the key for a hash table.
     */
    public String askForKey(String type){
        String key = "",firstName, lastName;
        int account;
        Scanner sc = new Scanner(System.in);
        Scanner scInt = new Scanner(System.in);
        //If key is by name, prompt for user's first and last names
        if(type.toLowerCase().equals("name")){
            System.out.println("Enter first name:");
            firstName = catchExceptionsString(sc);
            System.out.println("Enter last name:");
            lastName = catchExceptionsString(sc);
            key = (firstName+lastName).toLowerCase();
        }
        //if the key is by account, prompt for user's account number
        else if(type.toLowerCase().equals("account")){
            System.out.print("\nEnter account number: ");
            account = catchExceptionsInt(scInt);
            key = "" + account;
        }
        return key;
    }

    /**
     * @author Lidice Castro
     * @param key Parameter of type key which is used to verify its existence in the given hashtable.
     * @param ht Parameter of type Hashtable used to verify that the given key is mapped.
     * @return Returns a boolean variable that indicates if the key exists in the hashtable or the contrary.
     */
    public boolean verifyKey(Hashtable<String, Customer> ht, String key){
        try{
            if(ht.containsKey(key.toLowerCase())){
                return true;
            }
            else{
                throw new BankException("User/account doesn't exist. Please, try again.");
            }
        }
        //Otherwise, print custom exception message and repeat loop
        catch(Exception e) {
            System.out.println("\n" + e.toString());
        }
        return false;
    }

    /**
     * Method that asks the user if he/she wants to try with another user when the information entered is not valid.
     * @return Returns a boolean that indicates the answer of the user.
     */
    public boolean tryAnotherUser(){
        Scanner scInt = new Scanner(System.in);
        System.out.println("\nWould you like to try another user?\n1. Yes\n2. No");
        int ans = catchExceptionsInt(scInt,2);
        if(ans == 2){
            return false;
        }
        return true;
    }

    /**
     * @author Laura Blanco
     * This methods reads the transaction actions file and executes it.
     * @param ht Parameter of type Hash table that contains the data of the bank users file.
     * @param bht Parameter of type BankHT.
     */
    public void readFileTransactions(Hashtable<String,Customer> ht, BankHT bht){
        BankLog bl = new BankLog();
        try{
            BufferedReader br = new BufferedReader(new FileReader("Transaction Actions.csv")); //reads the file under this name
            String line = br.readLine();                       //To skip line one
            while ((line = br.readLine()) != null) { //reads line by line until one is found null
                String [] data = line.split(","); //splits each line by the comma and saves it to an array
                double money;
                Customer firstAcc = bht.getUserInfo(data[0]+data[1],ht);
                if(data[3].equals("pays")){         //if the actions is pays calls specific method to perform this action
                    Customer secAcc = bht.getUserInfo(data[4]+data[5],ht);
                    firstAcc.paySomeone(Double.parseDouble(data[7]),secAcc,data[2],data[6],true); //here we put true in the parameter so that we don't print success onto console only failures
                }else if(data[3].equals("transfers")){  //if the actions is transfers calls specific method to perform this action
                    money = Double.parseDouble(data[7]);    //will parse the string of money to a double to be able to use it
                    firstAcc.transfer(money,data[2],data[6],true);
                }else if(data[3].equals("inquires")){   //if the actions is inquires calls specific method to perform this action
                    if(data[2].equals("Checking")){
                        firstAcc.getCheck().getBalance();
                        BankLog.successfulTransactions(firstAcc.getCheck().getBalance(),"inquiry","checking","null",firstAcc,firstAcc);
                    }
                    else if(data[2].equals("Savings")){
                        firstAcc.getSaving().getBalance();
                        BankLog.successfulTransactions(firstAcc.getSaving().getBalance(),"inquiry","saving","null",firstAcc,firstAcc);
                    }else if(data[2].equals("Credit")){
                        firstAcc.getCredit().getBalance();
                        BankLog.successfulTransactions(firstAcc.getCredit().getBalance(),"inquiry","credit","null",firstAcc,firstAcc);
                    }
                }else if(data[3].equals("withdraws")){  //if the actions is withdraws calls specific method to perform this action
                    money = Double.parseDouble(data[7]);
                    if(data[2].equals("Savings")){
                        firstAcc.getSaving().withdraw(money,firstAcc,true);
                    }else if(data[2].equals("Checking")){
                        firstAcc.getCheck().withdraw(money,firstAcc,true);
                    }
                }else if(data[3].equals("deposits")){  //if the actions is deposits calls specific method to perform this action
                    Customer Acc = bht.getUserInfo(data[4]+data[5],ht);
                    money = Double.parseDouble(data[7]);
                    if(data[6].equals("Checking")){
                        if(Acc.getCheck().verifyDeposit(money, Acc)){
                            Acc.getCheck().deposit(money);
                            Acc.addToTransactions("deposit", Acc.getCheck(), money);
                            BankLog.successfulTransactions(money, "deposited", "checking", "checking",Acc,Acc);
                        }
                    }else if(data[6].equals("Savings")){
                        if(Acc.getSaving().verifyDeposit(money,Acc)){
                            Acc.getSaving().deposit(money);
                            Acc.addToTransactions("deposit", Acc.getSaving(), money);
                            BankLog.successfulTransactions(money, "deposited", "saving", "saving",Acc,Acc);
                        }
                    }
                    else if(data[6].equals("Credit")){
                        if(Acc.getCredit().verifyDeposit(money,Acc)){
                            Acc.getSaving().deposit(money);
                            Acc.addToTransactions("deposit", Acc.getCredit(), money);
                            BankLog.successfulTransactions(money, "deposited", "credit", "credit",Acc,Acc);
                        }
                    }
                }
            }
        }catch (FileNotFoundException exception) { //catches error if file isn't found
            System.out.println("File was not found");
            System.exit(0);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}