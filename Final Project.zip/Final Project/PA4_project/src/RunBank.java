import java.util.Hashtable;

/**
 * Main class that controls everything the bank can perform
 * @author Lidice Castro
 * @author Laura Blanco
 * @version 4, November 7,2020
 */

public class RunBank {

    public static void main(String[] args){
        //Variables and objects
        String fileName = "CS 3331 - Bank Users 4.csv";
        int selectUser;
        int transactionNum;
        Customer savedAccount; //Holds the current user account that is logged in
        BankHT bht = new BankHT(fileName);
        Hashtable<String, Customer> bankUsersByName = bht.getUsersByNameHT();
        UserInterface ui = new UserInterface(bankUsersByName);
        BankManagerModel bkm = new BankManagerModel();
        BankLog logging = new BankLog();
        //Create log file
        logging.createFile();
        //MAIN MENU INFINITE LOOP
        System.out.println("\n----------------------------------------------------------------");
        System.out.println("\nWelcome to Disney's bank!");
        for(;;){
            //MAIN MENU
            System.out.println("\n----------------------------------------------------------------");
            System.out.println("MAIN MENU\n");
            System.out.println("Choose from the following");
            selectUser = ui.selectUserType(); //calls method that will print the menu and prompt user to determine who they are
            //ENTER USER TYPE
            if(selectUser == 1){
                savedAccount = ui.userAuthenticationPage(); //makes sure the user exists
                boolean access = ui.passwordVerify(savedAccount); //makes sure that the password is correct
                if(access) { //if correct then access account
                    System.out.print("----------------------------------------------------------------\n");
                    System.out.println("Welcome " + savedAccount.getFirstName() + " " + savedAccount.getLastName());
                    while (true) {
                        transactionNum = ui.selectCustomerTransaction(); //calls method in user interface to select the transaction
                        if (transactionNum != 6) {
                            String accountType = ui.selectAccount(transactionNum, savedAccount.getCheck().isHasAccount(), savedAccount.getSaving().isHasAccount(), savedAccount.getCredit().isHasAccount()); //selects from which account to perform transaction
                            savedAccount.executeUserTransaction(transactionNum, accountType, bankUsersByName); //performs the action the user wants to do
                        } else { //if transactionNum is 6 return to main menu
                            break;
                        }
                    }
                }
            }
            //BANK MANAGER MENU
            else if(selectUser == 2){
                ui.selectManagerTransaction(bht,bkm);
            }
            //TRANSACTION READER
            else if(selectUser == 3){
                System.out.println("\n----------------------------------------------------------------");
                System.out.println("TRANSACTIONS READER\n");
                ui.readFileTransactions(bankUsersByName,bht); //calls helper method to read the transactions
            }
            //EXIT
            else if(selectUser == 4){
                break;
            }
        }
        //Write new data of bank users (updated file)
        bht.writeData(bankUsersByName);
        //Write logs into file
        logging.print();
        //Print goodbye message
        System.out.println("\n----------------------------------------------------------------\n");
        System.out.println("Thank you for visiting Disney's bank!");
        System.out.println("--------------------------------------------------------------------\n\n");
    }

}
