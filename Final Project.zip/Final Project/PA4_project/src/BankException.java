/**
 * Class handles custom exceptions.
 * @author Lidice Castro
 * @version 4, September 9, 2020
 */

public class BankException extends Exception {
    public BankException(String s) {
        // Call parent constructor
        super(s);
    }
}