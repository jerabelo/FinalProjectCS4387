/**
 * Class that holds the methods regarding the logic of bank manager transactions.
 * @author Laura Blanco
 * @author Lidice Castro
 * @version 1, November 8, 2020
 */

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Scanner;

public class BankManagerModel extends UserInterface{

    //CONSTRUCTOR

    /**
     * Default constructor
     */
    BankManagerModel(){}

    /**
     * @author Lidice Castro
     * The following method prints the user information inquired by user name or account number.
     * @param user Parameter of type Customer that represents the user the bank manger wants to inquire their information.
     */
    public void printInquiredInfo(Customer user){
        //Print the user information
        System.out.println("User: " + user.getFirstName() + " " + user.getLastName() + "\n");
        System.out.println("First Name: " + user.getFirstName());
        System.out.println("Last Name: " + user.getLastName());
        System.out.println("Password: " + user.getPassword());
        System.out.println("Date of Birth: " + user.getDOB().replace("\"",""));
        System.out.println("Identification Number: " + user.getIdentificationNum());
        System.out.println("Address: " + user.getAddress().replace("\"",""));
        System.out.println("Phone Number: " + user.getPhoneNum());
        System.out.println("Email: " + user.getEmail());
        //Verify if the user has Checking account. If the user does, print the account's information.
        if(user.getCheck().isHasAccount()){
            System.out.println("Checking Account Number: " + user.getCheck().getAccountNumber());
            System.out.println("Checking Account Balance: " + user.getCheck().getBalance());
        }
        else{ //Otherwise, print blank spaces.
            System.out.println("Checking Account Number: -");
            System.out.println("Checking Account Balance: -");
        }
        //Print Savings account information
        System.out.println("Savings Account Number: " + user.getSaving().getAccountNumber());
        System.out.println("Savings Account Balance: " + user.getSaving().getBalance());
        //Verify if the user has Credit account. If the user does, print the account's information.
        if(user.getCredit().isHasAccount()){
            System.out.println("Credit Account Number: " + user.getCredit().getAccountNumber());
            System.out.println("Credit Account Balance: " + user.getCredit().getBalance());
            System.out.println("Credit Max: " + user.getCredit().getMaxBal());
        }
        else{ //Otherwise, print blank spaces.
            System.out.println("Credit Account Number: -");
            System.out.println("Credit Account Balance: -");
            System.out.println("Credit Max: -");
        }
    }

    /**
     * @author Laura Blanco
     * Method that prompts for the information to create a new user.
     * @param ht Hashtable in which the new user will be added.
     */
    public void newUser(Hashtable<String, Customer> ht){  //will create a new user
        //Variables
        Scanner scInt = new Scanner(System.in);
        Scanner scString = new Scanner(System.in);
        String first, last, day="", dob="", month="", year="", phone="", password="", email="", address="";
        int userOpt;
        String[] monthNames = {"","January","February","March","April","May","June","July","August","September","October","November","December"};

        System.out.println("----------------------------------------------------------------");
        System.out.println("NEW USER MENU");

        //Prompt for new user's name
        do{
            System.out.println("\nPlease enter the following information:\n"); //prompts the user to enter all the information needed to create a new user
            System.out.println("Enter first name:");
            first = catchExceptionsString(scString);
            System.out.println("Enter last name:");
            last = catchExceptionsString(scString);
            //Set name to a correct format
            if(first.length() > 1){
                String l = "" + first.charAt(0);
                first = l.toUpperCase() + first.substring(1,first.length());
            }
            else{
                first = first.toUpperCase();
            }
            if(last.length() > 1){
                String l = "" + last.charAt(0);
                last = l.toUpperCase() + last.substring(1,last.length());
            }
            else{
                last = last.toUpperCase();
            }
        }
        while(!verifyEnterName(ht,first,last));

        //Promp for day of birth
        do{
            System.out.println("Enter DOB (mm/dd/yyyy):");
            dob = catchExceptionsString(scString);
            String[] temp = dob.split("/");
            if(temp.length == 3){
                month = temp[0];
                day = temp[1];
                year = temp[2];
            }
        }
        while(!verifyEnterDOB(day,month,year,"MM-dd-yyyy"));

        //Assign dob with the correct format
        dob = "\"" + monthNames[Integer.parseInt(month)] + " " + day + ", " + year + "\"";

        //Prompt for the new user's address
        do{
            System.out.println("Enter Address");
            address = catchExceptionsString(scString);
            address = "\"" + address + "\"";

        }while(!verifyEnterAddress(address));

        //Prompt for the new user's phone number
        do{
            System.out.println("Enter phone number");
            phone = catchExceptionsString(scString);
        }while(!verifyEnterPhoneNumber(phone));

        phone = phone.replaceAll("\\D\\s","");
        phone = "(" + phone.substring(0,3) + ") " + phone.substring(3,6) + "-" + phone.substring(6,10);

        //Prompt for the new user's password
        password = newPassword();

        //Assign new user's email
        email = first + last + "@disney.com";

        //Ask what types of bank accounts will be created for the new user
        System.out.println("\nWould you like to create: ");  //asks the user what accounts they want to create
        System.out.println("1. Checking account");
        System.out.println("2. Credit account ");
        System.out.println("3. Neither");
        System.out.println("4. Both");
        userOpt = catchExceptionsInt(scInt,4);

        //Assign the new id and account numbers
        int newMax = ht.size();
        int newIdentify = newMax + 1;   //will give the user an identification number starting from the last user
        int newSavNum = 2000 +newMax;  //will also give the user new account numbers starting from the greatest and adding one
        int newCheckNum = 1000 + newMax;
        int newCredNum = 3000 + newMax;
        String key = first + last;

        //Add the new user to the hash table
        if(userOpt == 1){  //if the user only wants to create a checking account it will create that plus a savings account because they are needed
            ht.put(key.toLowerCase(),new Customer(first, last,dob,newIdentify, address, phone, password, email, new Checking(newCheckNum,700,true),new Savings(newSavNum,100,true), new Credit(0,0,0,false)));
            System.out.println("\nWelcome you are now a new bank user with a checking and savings account!");
        }
        else if(userOpt == 2){ //for all options it will call the same customer constructor but will set the values to 0 for the ones the user did not want to create
            ht.put(key.toLowerCase(),new Customer(first, last,dob, newIdentify, address, phone, password, email, new Checking(0,0,false),new Savings(newSavNum,100,true), new Credit(newCredNum,-100,500,true)));
            System.out.println("\nWelcome you are now a new bank user with a credit and savings account!");
        }
        else if(userOpt == 3){
            ht.put(key.toLowerCase(),new Customer(first, last,dob, newIdentify, address, phone, password, email, new Checking(0,0,false),new Savings(newSavNum,100,true), new Credit(0,0,0,false)));
            System.out.println("\nWelcome you are now a new bank user without a credit or checking account!");
        }
        else if(userOpt == 4){
            ht.put(key.toLowerCase(),new Customer(first, last,dob, newIdentify, address, phone, password, email, new Checking(newCheckNum,700,true),new Savings(newSavNum,100,true), new Credit(newCredNum,-100,500,true)));
            System.out.println("\nWelcome you are now a new bank user with a credit, checking, and savings account!");
        }
    }

    /**
     * @author Lidice Castro
     * Method that prompts for password for new user.
     * @return Returns a variable of type String that contains the new password.
     */
    public String newPassword(){
        Scanner sc = new Scanner(System.in);
        while(true){
            try{
                System.out.println("Enter password: ");
                String password1 = sc.nextLine();
                System.out.println("Retype the new password: ");
                String password2 = sc.nextLine();

                if(password1.equals(password2)){
                    System.out.println("\nPassword succesfully set!");
                    return password1;
                }
                else{
                    throw new BankException ("Password mismatch. Try again.");
                }
            }
            catch(BankException e) {
                System.out.println("\n" + e.toString() + "\n");
            }
        }
    }

    /**
     * @author Laura Blanco
     * Method that verifies if the new user's name is valid.
     * @param ht Hash table that contains the bank users ordered by name
     * @param firstName Parameter of type String that corresponds to the user's first name
     * @param lastName Parameter of type String that corresponds to the user's last name
     * @return Returns a boolean value that indicates if the name is valid.
     */
    public boolean verifyEnterName(Hashtable<String, Customer> ht, String firstName, String lastName){
        try{
            //Check name is not blank
            if(firstName.equals("") || lastName.equals("")){
                throw new BankException("First name of last name is blank.");
            }
            //Check user doesn't exist
            else if(ht.containsKey((firstName+lastName).toLowerCase())){
                throw new BankException("User/account already exist. Please, try again.");
            }
            else{
                return true;
            }
        }
        //Otherwise, print custom exception message and repeat loop
        catch(BankException e) {
            System.out.println("\n" + e.toString());
        }
        return false;
    }

    /**
     * @author Lidice Castro
     * Method that verifies if the new user's date of birth is valid.
     * @param dayIn Parameter of type String that contains the day of date of birth.
     * @param monthIn Parameter of type String that contains the month of date of birth.
     * @param yearIn Parameter of type String that contains the year of date of birth.
     * @param dateFormat Parameter of type String that contains the format for the date.
     * @return Returns a boolean value that indicates if the date of birth is valid.
     */
    public boolean verifyEnterDOB(String dayIn, String monthIn, String yearIn, String dateFormat){

        //variables and objects
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        sdf.setLenient(false);

        try {
            //If not number, throws Number Format Exception
            this.isNumeric(dayIn);
            this.isNumeric(monthIn);
            this.isNumeric(yearIn);

            //If not in the correct length throws Bank Exception.
            if (dayIn.length() != 2 || monthIn.length() != 2 || yearIn.length() != 4){
                throw new BankException("Date is not in the correct format (mm/dd/yyyy).");
            }
            String dob = monthIn + "-" + dayIn + "-" + yearIn;
            //if not valid, it will throw Parse Exception
            Date date = sdf.parse(dob);
        } catch(NumberFormatException e){
            System.out.println("\nNumberFormatException: Date is not in a valid format (mm/dd/yyyy)");
            return false;
        } catch (ParseException e) {
            System.out.println("\nParseException: Date is not valid (mm/dd/yyyy)");
            return false;
        } catch(BankException e) {
            System.out.println("\n" + e.toString());
            return false;
        }
        return true;
    }

    /**
     * @author Lidice Castro
     * Method that verifies if a given number is numeric. If not, it throws an exception.
     * @param numStr Parameter of type String that contains a number.
     * @throws NumberFormatException
     */
    public void isNumeric(String numStr) throws NumberFormatException{
        //try to convert the String into a double
        double d = Double.parseDouble(numStr);
    }

    /**
     * @author Lidice Castro
     * Method that verifies if the new user's phone number is valid.
     * @param phoneNumberIn String that contains the new user's phone number to verify.
     * @return Returns a boolean value that indicates if the phone number is valid.
     */
    public boolean verifyEnterPhoneNumber(String phoneNumberIn){
        try{
            //Check if the phone number is blank
            if(phoneNumberIn.equals("")){
                throw new BankException("Phone number field is blank.");
            }
            //Remove parenthesis and dashes
            String phoneNumber = phoneNumberIn.replaceAll("(,),-,\\s","");
            //Check if the phone number is a number
            this.isNumeric(phoneNumber);
            //Check if the phone number has the correct length
            if(phoneNumber.length() != 10){
                throw new BankException("The phone number exceeds or misses digits (10 digits).");
            }
        }
        //Display Bank Exception
        catch(NumberFormatException e){
            System.out.println("\nException: Phone number contains illegal characters.");
            return false;
        } catch(BankException e) {
            System.out.println("\n" + e.toString());
            return false;
        }
        return true;
    }

    /**
     * @author Lidice Castro
     * Method that verifies if the new user's address is valid.
     * @param addressIn String that contains the new user's address to verify.
     * @return Returns a boolean value that indicates if the address is valid.
     */
    public boolean verifyEnterAddress(String addressIn){
        //Check if address string is blank
        try{
            if(addressIn.equals("")){
                throw new BankException("Address field is blank.");
            }
        }
        catch(BankException e) {
            System.out.println("\n" + e.toString());
            return false;
        }

        return true;
    }

    /**
     * @author Laura Blanco
     * This methods creates a new instance of BankStatement class and calls method to write a bank statement
     * @param user Parameter of type Customer that holds the current user
     */
    public static void createStatement(Customer user){  //writes a bank statement
        BankStatement statement = new BankStatement(user);
        boolean result = statement.print(); //uses instance to call method to write the text file
        if (result){ //if the write to text file returns one then it was successful and we let the user know
            System.out.println("Successfully created a bank statement for: " + user.getFirstName() + " " + user.getLastName());
        }
        else{
            System.out.println("Unable to create bank statement");
        }
    }

}
