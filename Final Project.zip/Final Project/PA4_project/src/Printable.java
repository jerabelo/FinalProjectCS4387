/**
 * Interface class that has three methods to be implemented by other classes.
 * @author Laura Blanco
 * @author Lidice Castro
 * @version 4, November 7,2020
 */

import java.io.PrintWriter;

public interface Printable {

    //Method to create a file to write on.
    void createFile();

    //Method to print something in file
    boolean print();

    //Method used to print transactions
    void printTransactions(PrintWriter pw);


}
