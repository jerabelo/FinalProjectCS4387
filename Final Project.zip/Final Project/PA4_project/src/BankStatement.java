/**
 * Class that holds all the information relevant to the bank statement
 * @author Laura Blanco
 * @version 3, October 18,2020
 */

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class BankStatement implements Printable{

    //ATTRIBUTES
    private Customer user;
    private String firstName;
    private String lastName;
    private String address;
    private String DOB;
    private String phoneNum;
    private String email;
    private int identificationNum;
    private int checkNum;
    private int savNum;
    private int credNum;
    private double endBalSav;
    private double endBalCheck;
    private double endBalCred;
    private double begCheckBal;
    private double begSavBal;
    private double begCredBal;
    private boolean checkHasAccount;
    private boolean credHasAccount;
    private String fileName;
    private ArrayList<String[]> transactions;

    //CONSTRUCTORS

    /**
     * Default constructor
     */
    public BankStatement(){}

    /**
     * Constructor that has as parameter an object of type Customer and assigns the class attributes.
     * @param user Parameter of type Customer that represents the user.
     */
    public BankStatement(Customer user) {
        //Assign attributes by extracting the information from the user (Customer object).
        this.user = user;
        this.firstName = user.getFirstName();
        this.lastName = user.getLastName();
        this.address = user.getAddress();
        this.DOB = user.getDOB();
        this.phoneNum = user.getPhoneNum();
        this.email = user.getEmail();
        this.identificationNum = user.getIdentificationNum();
        this.checkNum = user.getCheck().getAccountNumber();
        this.savNum = user.getSaving().getAccountNumber();
        this.credNum = user.getCredit().getAccountNumber();
        this.endBalSav = Math.round(user.getSaving().getBalance() * 100.0) / 100.0;
        this.endBalCheck = Math.round(user.getCheck().getBalance() * 100.0) / 100.0;
        this.endBalCred = Math.round(user.getCredit().getBalance() * 100.0) / 100.0;
        this.begCheckBal = Math.round(user.getCheckBegBal() * 100.0) / 100.0;
        this.begSavBal = Math.round(user.getSavBegBal() * 100.0) / 100.0;
        this.begCredBal = Math.round(user.getCredBegBal() * 100.0) / 100.0;
        this.checkHasAccount = user.getCheck().isHasAccount();
        this.credHasAccount = user.getCredit().isHasAccount();
        this.transactions = user.getTransactions();
        this.fileName = "BankStatement_" + firstName + "_" + lastName + ".txt";  //creates the file name according to what the user is
        //Create bank statement file
        createFile();
    }

    /**
     * @author Lidice Castro
     * This method creates a new file to write the user's bank statement.
     */
    public void createFile(){
        try{
            FileWriter fw = new FileWriter (this.fileName, false);
            PrintWriter pw = new PrintWriter(this.fileName);
            //Print nothing, is just to create the file
            pw.print("");
            pw.close();
        }
        catch(IOException e){
            System.out.print("IOException: ");
            System.err.format("An error occurred while trying to write '%s'.\n", this.fileName);
        }
    }

    /**
     * @author Laura Blanco
     * This methods writes a bank statement for a given user
     * @return int This will let it know whether it was successful or not
     */
    public boolean print(){  //method will write the text to a text file for bank statement

        //try catch to make sure we catch if we can't write to it
        try{
            FileWriter fw = new FileWriter (this.fileName, true); //FileWriter object
            PrintWriter pw = new PrintWriter(fw); //PrintWritter object
            printHeader(pw);
            printTransactions(pw);
            pw.close();
            return true; //returns 1 for successful completion

        } catch (IOException e) {
            e.printStackTrace();
        }
        return false; //returns 0 if it could not write to the file
    }

    /**
     * @author Laura Blanco
     * @author Lidice Castro
     * The following method prints the header of the bank statement in the file.
     * @param pw Parameter of type PrintWriter to print in file
     */
    private void printHeader(PrintWriter pw){
        //SimpleDateFormat formatter= new SimpleDateFormat("MM-dd-yyyy 'at' HH:mm:ss");
        SimpleDateFormat formatter= new SimpleDateFormat("MM-dd-yyyy");
        //Get current date and time
        Date date = new Date();
        pw.print("\nDisney's Bank\t\t\t\t\t\t\t\t\t\t\t\t\tAccount Statement\n");
        //Print the date the bank statement is generated
        pw.println("Statement Date: " + formatter.format(date) + "\n");
        //User information
        pw.println(this.firstName + " " + this.lastName);
        pw.println("Address: " + this.address);
        pw.println("Phone Number: " + this.phoneNum);
        pw.println("Email: " + this.email);
        pw.println("ID: " + this.identificationNum + "\n");
        //Account information
        pw.println("Account(s) Information:");
        pw.println("-----------------------------------------------------------------------");
        pw.println("Account\t\tNumber\t\tStart Balance\t\tEnd Balance");
        if(this.checkHasAccount){
            pw.print("Checking\t" + this.checkNum + "\t\t" + this.begCheckBal + "\t\t\t" + this.endBalCheck + "\n");
        }
        pw.print("Savings\t\t" + this.savNum + "\t\t" + this.begSavBal + "\t\t\t" + this.endBalSav + "\n");
        if(this.credHasAccount){
            pw.print("Credit\t\t" + this.credNum + "\t\t" + this.begCredBal + "\t\t" + this.endBalCred + "\n");
        }
        pw.println();
    }

    /**
     * @author Laura Blanco
     * @author Lidice Castro
     * The following method prints the user's transactions in the bank statement.
     * @param pw Parameter of type PrintWriter to print in file
     */
    public void printTransactions(PrintWriter pw){

        pw.println("Transactions:");
        pw.println("----------------------------------------------------------------------------------------------------------------------------------");
        pw.println("Date\t\tDescription\t\tChecking\tBalance\t\tSavings\t\tBalance\t\tCredit\t\tBalance");
        pw.println("\t\t\t\t\t\t\tChecking\t\t\tSavings\t\t\t\tCredit\t");
        //Print what's in the transactions array list
        for(String[] strArr: this.transactions){
            for(int i = 0; i<strArr.length; i++){
                //For the first column just add one tab
                if(i == 0){
                    pw.print(strArr[0] + "\t");
                }
                //If the second column length exceeds 15 characters, just add one tab
                else if(i == 1 && strArr[1].length() > 15){
                    pw.print(strArr[i] + "\t");
                }
                //If any field is null, print to tabs
                else if(strArr[i] ==  null){
                    pw.print("\t\t");
                }
                //If a column value (after the second) length exceeds 7 characters, just add one tab
                else if(i > 1 && strArr[i].length() > 7){
                    pw.print(strArr[i] + "\t");
                }
                //For everything else, add two tabs
                else{
                    pw.print(strArr[i] + "\t\t");
                }
            }
            pw.println();
        }
    }

}
