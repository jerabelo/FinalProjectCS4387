/**
 * Abstract class that holds the account number and balance for accounts
 * @author Laura Blanco
 * @author Lidice Castro
 * @version 4, November 7, 2020
 */

public abstract class Account {

    //ATTRIBUTES
    private int accountNumber;
    private double Balance;
    private boolean hasAccount;
    private String name;

    //CONSTRUCTORS
    public Account(){ //default constructor
    }

    /**
     * This constructor will set the account number and balance
     * @param accountNumber Parameter is the account number
     * @param Balance Parameter is the balance
     * @param hasAccount Parameter that determines whether the user has this type of account
     */
    public Account(int accountNumber, double Balance, boolean hasAccount, String name){ //constructor for account number and balance for all accounts
        this.accountNumber = accountNumber;
        this.Balance = Balance;
        this.hasAccount = hasAccount;
        this.name = name;
    }

    //SETTERS AND GETTERS
    public String getName(){
        return name;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getBalance() {
        return Balance;
    }

    public void setBalance(double balance) {
        Balance = balance;
    }

    public boolean isHasAccount() {
        return hasAccount;
    }

    public void setHasAccount(boolean hasAccount) {
        this.hasAccount = hasAccount;
    }

    //METHODS

    /**
     * @author Laura Blanco
     * This methods deposits money into checking account
     * @param money Parameter of type double which amount to be payed
     */
    public double deposit(double money){ //boolean isReader){
        setBalance(this.Balance + money); // sets new balance
        return this.getBalance();
    }

    /**@author Lidice Castro
     * This method verifies that the deposit is valid
     * @param amountIn Parameter of type double that contains the amount to deposit
     * @param user Customer object the current user paying
     */
    public boolean verifyDeposit(double amountIn, Customer user){
        String denial = "";
        //If any of these conditions are true, the transaction is unsuccessful
        if(this instanceof Checking || this instanceof Savings){
            if (amountIn > 0){
                //Return true, meaning transaction was succesful
                return true;
            }
            else{
                denial = "Invalid amount, value is a negative number or zero. Please, try again";
            }
        }
        else if (this instanceof Credit){ //different if conditions if its a credit type
            if (this.getBalance() != 0){
                if(this.getBalance() < 0 && amountIn <= Math.abs(this.getBalance())){
                    //successful so return true
                    return true;
                }
                else{
                    denial = "Amount value should not exceed credit debt.";
                }
            }
            else{
                denial = "Your credit balance is zero. Cannot proceed with deposit.";
            }
        }

        //logs failed transaction and reason
        BankLog.failedTransaction(amountIn, "deposited",this.name, user,denial,user);
        System.out.println(denial);
        return false;
    }

    /**
     * @author Lidice Castro
     * @author Laura Blanco
     * This method performs the withdrawal if valid
     * @param amountIn Amount to withdraw from the account.
     * @param user Customer object the current user paying
     */
    public boolean withdrawMoney(double amountIn, Customer user){
        String denial = "";
        //If any of these conditions are true, the transaction is unsuccessful
        if (this.getBalance() < amountIn){
            denial = "Insufficient balance";
        }
        else if (amountIn <= 0){
            denial = "Invalid amount, value is a negative number or zero. Please, try again";
        }
        //Otherwise:
        else{
            this.setBalance(this.getBalance() - amountIn);
            //transaction successful
            return true;
        }
        //logs failed transaction
        BankLog.failedTransaction(amountIn,"withdraw",this.name,user,denial,user);
        System.out.println(denial);
        return false;
    }

    /**
     * @author Laura Blanco
     * This methods withdraws money from checking account
     * @param money Parameter of type double which amount to be payed
     * @param isReader Parameter of type boolean lets me know if caller is transaction reader
     */
    public void withdraw(double money, Customer user, boolean isReader){
        String denial;
        if(this.hasAccount) {
            if (money < 0) { //will not go through if value is negative
                System.out.println("Invalid number you can not withdraw negative values");
            } else if ((this.Balance - money) >= 0) { //If there's enough balance
                setBalance(this.Balance - money);
                if (!isReader) { //will only print success if its not the transaction reader
                    System.out.println("Successfully withdrew: " + money);
                    System.out.println("New account balance: " + getBalance());
                }
                //Add to transactions array list for Bank Statement
                user.addToTransactions("withdrawal", this, money);
                if(this.name.toLowerCase().equals("checking")){
                    BankLog.successfulTransactions(money,"withdrew","checking","checking", user,user);
                }
                else{
                    BankLog.successfulTransactions(money,"withdrew","saving","saving", user,user);
                }

            } else {
                denial="Unable to withdraw: " + money + " insufficient funds.";
                System.out.println(denial);
                BankLog.failedTransaction(money,"withdraw",this.name,user,denial,user);
            }
        } else{
            denial="You don't have a checking account you can't perform this action";
            System.out.println(denial);
            BankLog.failedTransaction(money,"withdraw",this.name,user,denial,user);
        }
    }

    /**
     * @author Lidice Castro
     * @author Laura Blanco
     * This method transfers money if valid
     * @param amountIn Amount to transfer to account.
     * @param recipientIn Account object of the recipient.
     * @param user Customer object the current user paying
     */
    public boolean transferMoney(double amountIn, Account recipientIn, Customer user){
        String denial = "";
        //if any of these are true then return false because it was not succesful
        if(amountIn <= 0){
            denial = "Invalid amount, value is a negative number or zero. Please, try again";
        }
        else if (this.getBalance() < amountIn){
            denial = "Insufficient balance.";
        }
        else if (recipientIn instanceof Credit){
            if (recipientIn.getBalance() != 0){
                //check credit balance
                if(recipientIn.getBalance() < 0 && amountIn <= Math.abs(recipientIn.getBalance())){
                    recipientIn.setBalance(recipientIn.getBalance() + amountIn);
                    this.setBalance(this.getBalance()-amountIn); //updates new balance
                    return true;
                }
                else{
                    denial = "Amount value should not exceed credit debt.";
                }
            }
            else{
                denial = "Your credit balance is zero. Cannot proceed with deposit.";
            }
        }
        else{
            //set new balance of both accounts
            recipientIn.setBalance(recipientIn.getBalance() + amountIn);
            this.setBalance(this.getBalance()-amountIn);
            return true;
        }
        //logs failed transaction
        BankLog.failedTransaction(amountIn, "transfer",recipientIn.getName(),user,denial,user);
        System.out.println(denial);
        return false;
    }

    /**
     * @author Lidice Castro
     * @author Laura Blanco
     * This method pays another user if valid
     * @param amountIn Amount to deposit to recipient.
     * @param recipientIn Customer object of the recipient.
     * @param user Customer object the current user paying
     */
    public boolean paySomeone(double amountIn, Customer recipientIn, Customer user){
        String denial = "";
        //check that the amount is valid
        if (this.getBalance() < amountIn) {
            denial = "Insufficient balance";
        } else if (amountIn <= 0) {
            denial = "Invalid amount, value is a negative number or zero. Please, try again";
        } else if (this.getAccountNumber() == recipientIn.getCheck().getAccountNumber() || this.getAccountNumber() == recipientIn.getSaving().getAccountNumber()) {
            denial = "Recipient can't be the same as user.";
        }
        //Otherwise:
        else {
            //Add the amount to the balance of the recipient
            recipientIn.getCheck().setBalance(recipientIn.getCheck().getBalance() + amountIn);
            //Subtract the quantity to the balance of the user
            this.setBalance(this.getBalance()-amountIn);
            //Return true, meaning transaction successful
            return true;
        }
        //logs failed transaction
        BankLog.failedTransaction(amountIn,"pay",this.name,recipientIn,denial,user);
        System.out.println(denial);
        return false;
    }

}
