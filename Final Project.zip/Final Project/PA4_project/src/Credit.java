/**
 * Class that holds the credit account balance and number and inherits from account class.
 * @author Laura Blanco
 * @version 4, November 7,2020
 */

public class Credit extends Account{
    //ATTRIBUTES
    private double maxBal;

    //CONSTRUCTOR
    public Credit(){
        super();
    }   //calls parent class

    //Constructor to set the attributes to the object
    /**
     * This constructor will set the account number and balance
     * @param accountNumberIn Parameter is the account number of credit account
     * @param balanceIn Parameter is the balance of credit account
     * @param Max Parameter is the max for credit account
     * @param hasAccount Parameter that determines whether the user has this type of account
     */
    public Credit( int accountNumberIn,double balanceIn, double Max, boolean hasAccount){
        super(accountNumberIn,balanceIn,hasAccount, "Credit"); //calls parent class constructor
        this.maxBal = Max;
    }

    //SETTERS AND GETTERS
    public void setMaxBal(int maxBal){ this.maxBal = maxBal; }
    public double getMaxBal(){ return maxBal; }

}
